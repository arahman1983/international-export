module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ({

/***/ "+8UP":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"speedContact": "speedContact_speedContact__3A2tY",
	"icon": "speedContact_icon__sGxrZ",
	"phoneNo": "speedContact_phoneNo__14syG"
};


/***/ }),

/***/ "/jkW":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.isDynamicRoute = isDynamicRoute; // Identify /[param]/ in route string

const TEST_ROUTE = /\/\[[^/]+?\](?=\/|$)/;

function isDynamicRoute(route) {
  return TEST_ROUTE.test(route);
}

/***/ }),

/***/ "04F5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ useTranslation; });

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// EXTERNAL MODULE: ./locals/langProvider.tsx
var langProvider = __webpack_require__("QMtg");

// CONCATENATED MODULE: ./locals/localStrings.ts
const LangStrings = {
  en: {
    Dir: "ltr",
    websiteTitle: "International Export",
    Home: "Home",
    About: "About",
    Products: "Products",
    Brands: "Brands",
    Contact: "Contact us",
    ReadMore: "Reade More",
    ChangeLang: "Ar",
    EmailUs: "Email us",
    Email: "Please enter valid email",
    Subject: "Message subject",
    Message: "Message",
    Send: "Send",
    ContactInfo: "Contact Information",
    CopyRights: "All Copy Rights are received to International Export 2020",
    LoginHead: "Log in",
    EmailInput: "Please Enter your Email",
    PasswordInput: "Please Enter your password",
    Categories: 'Categories',
    AdBrands: 'Brands',
    AdProducts: 'Products',
    Users: 'Users',
    Add: 'Add New',
    Edit: 'Edit Item',
    Delete: 'Delete Item',
    Cancel: "Cancel",
    Title: "Title",
    ArTitle: "Arabic Title",
    Description: "Description",
    ArDescription: "Arabic Description",
    Details: "Details",
    ArDetails: "Arabic Details",
    Save: "Save",
    CrDate: "Created Date",
    UpDate: "Updated Date",
    ActiveItem: "Active Items",
    DeleteItem: "Delete Item",
    RestoreItem: "Restore Item",
    All: "All",
    FilterDelete: "Filter Items",
    ConfirmMessage: "Do you really want to delete this item ?",
    EnglishName: 'English Name',
    ArabicName: "Arabic Name",
    Image: 'Picture',
    Slide: 'Main Slide',
    Roles: 'Roles',
    KeyWords: 'Key Words',
    EmailTitle: 'Email',
    UserName: 'Username',
    Password: 'Password',
    Phones: 'Phones',
    Address: 'Address',
    ChangePassword: 'Change Password',
    OldPassword: 'Old Password',
    NewPassword: 'New Password',
    CoPassword: 'Confirm Password'
  },
  ar: {
    Dir: "rtl",
    websiteTitle: "إنترناشيونال إكسبورت",
    Home: "الرئيسية",
    About: "حول الشركة",
    Products: "منتجاتنا",
    Brands: "علامات تجارية",
    Contact: "تواصل معنا",
    ReadMore: "المزيد",
    EmailUs: "راسلنا",
    Email: "من فضلك أدخل بريد صحيح",
    Subject: "عنوان الرسالة",
    Message: "الرسالة",
    Send: "أرسل",
    ContactInfo: "معلومات التواصل",
    CopyRights: " جميع الحقوق محفوظة 2020",
    ChangeLang: "En",
    LoginHead: "تسجيل الدخول",
    EmailInput: "البريد الالكتروني",
    PasswordInput: "من فضلك أدخل كلمة المرور",
    Categories: 'التصنيفات',
    AdBrands: 'العلامات التجارية',
    AdProducts: 'المنتجات',
    Users: 'المستخدمين',
    Add: 'إضافة جديد',
    Edit: 'تعديل',
    Delete: 'حذف',
    Title: "عنوان",
    ArTitle: "العنوان العربي",
    Description: "الوصف الانجليزي",
    ArDescription: "الوصف العربي",
    Details: "التفاصيل الانجليزي",
    ArDetails: "التفاصيل العربي",
    Save: "Save",
    CrDate: "تاريخ الانشاء",
    UpDate: "تاريخ التعديل",
    ActiveItem: "العناصر النشطة",
    DeleteItem: "العناصر المحذوفة",
    All: "كل العناصر",
    RestoreItem: "اعادة تنشيط العنصر",
    FilterDelete: "فرز العناصر",
    ConfirmMessage: "هل أنت متأكد من حذف هذا العنصر ؟",
    EnglishName: 'اسم انجليزي',
    ArabicName: "اسم عربي",
    Image: 'اختر صورة ',
    Slide: 'العرض الرئيسي',
    Roles: 'الصلاحيات',
    KeyWords: 'الكلمات الدلالية',
    EmailTitle: 'البريد الالكتروني',
    UserName: 'اسم المستخدم',
    Password: 'كلمة المرور',
    Phones: 'التليفونات',
    Address: 'العنوان',
    ChangePassword: 'تغيير كلمة المرور',
    OldPassword: 'كلمة المرور القديمة',
    NewPassword: 'كلمة مرور جديدة',
    CoPassword: 'تأكيد كلمة المرور الجديدة'
  }
};
// CONCATENATED MODULE: ./locals/localHook.tsx



function useTranslation() {
  const {
    0: locale
  } = Object(external_react_["useContext"])(langProvider["a" /* LanguageContext */]);

  function t(key) {
    // if(!LangStrings[locale][key]){
    //   console.log("This key has no value in strings object")
    // }
    return LangStrings[locale][key] || LangStrings[langProvider["c" /* defaultLocal */]][key] || "";
  }

  return {
    t,
    locale
  };
}

/***/ }),

/***/ "07Px":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"sideMenu": "sideMenu_sideMenu__1fCcD",
	"sideMenuCollapsed": "sideMenu_sideMenuCollapsed__1k_Ku",
	"toggleBtn": "sideMenu_toggleBtn__AT-Av",
	"sideMenuUl": "sideMenu_sideMenuUl__GpbzA",
	"sideItem": "sideMenu_sideItem__2Aryf",
	"sideItemActive": "sideMenu_sideItemActive__1rQF3",
	"sideLink": "sideMenu_sideLink__3KhY5"
};


/***/ }),

/***/ "0Bsm":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("TqRt");

exports.__esModule = true;
exports.default = withRouter;

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router = __webpack_require__("nOHt");

function withRouter(ComposedComponent) {
  function WithRouterWrapper(props) {
    return /*#__PURE__*/_react.default.createElement(ComposedComponent, Object.assign({
      router: (0, _router.useRouter)()
    }, props));
  }

  WithRouterWrapper.getInitialProps = ComposedComponent.getInitialProps // This is needed to allow checking for custom getInitialProps in _app
  ;
  WithRouterWrapper.origGetInitialProps = ComposedComponent.origGetInitialProps;

  if (false) {}

  return WithRouterWrapper;
}

/***/ }),

/***/ "0G5g":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

var _default = requestIdleCallback;
exports.default = _default;

/***/ }),

/***/ "1XTA":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"header": "adminHeader_header__2HocZ"
};


/***/ }),

/***/ "284h":
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__("cDf5");

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function _getRequireWildcardCache() {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
    return {
      "default": obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj["default"] = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

module.exports = _interopRequireWildcard;

/***/ }),

/***/ "3WeD":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.searchParamsToUrlQuery = searchParamsToUrlQuery;
exports.urlQueryToSearchParams = urlQueryToSearchParams;
exports.assign = assign;

function searchParamsToUrlQuery(searchParams) {
  const query = {};
  searchParams.forEach((value, key) => {
    if (typeof query[key] === 'undefined') {
      query[key] = value;
    } else if (Array.isArray(query[key])) {
      ;
      query[key].push(value);
    } else {
      query[key] = [query[key], value];
    }
  });
  return query;
}

function stringifyUrlQueryParam(param) {
  if (typeof param === 'string' || typeof param === 'number' && !isNaN(param) || typeof param === 'boolean') {
    return String(param);
  } else {
    return '';
  }
}

function urlQueryToSearchParams(urlQuery) {
  const result = new URLSearchParams();
  Object.entries(urlQuery).forEach(([key, value]) => {
    if (Array.isArray(value)) {
      value.forEach(item => result.append(key, stringifyUrlQueryParam(item)));
    } else {
      result.set(key, stringifyUrlQueryParam(value));
    }
  });
  return result;
}

function assign(target, ...searchParamsList) {
  searchParamsList.forEach(searchParams => {
    Array.from(searchParams.keys()).forEach(key => target.delete(key));
    searchParams.forEach((value, key) => target.append(key, value));
  });
  return target;
}

/***/ }),

/***/ "4GzE":
/***/ (function(module) {

module.exports = JSON.parse("{\"v\":\"5.4.2\",\"fr\":50,\"ip\":0,\"op\":120,\"w\":500,\"h\":500,\"nm\":\"MailFull\",\"ddd\":0,\"assets\":[],\"layers\":[{\"ddd\":0,\"ind\":1,\"ty\":4,\"nm\":\"mailhigh Outlines - Group 11\",\"parent\":5,\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":0,\"k\":[150,143.582,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[150,143.582,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":1,\"k\":[{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"n\":\"0p833_0p833_0p167_0p167\",\"t\":11,\"s\":[{\"i\":[[0,0],[0,0],[0,0]],\"o\":[[0,0],[0,0],[0,0]],\"v\":[[57.911,-28.585],[0.001,28.585],[-57.91,-28.585]],\"c\":true}],\"e\":[{\"i\":[[0,0],[0,0],[0,0]],\"o\":[[0,0],[0,0],[0,0]],\"v\":[[57.911,-28.585],[0.001,-85.915],[-57.91,-28.585]],\"c\":true}]},{\"t\":16}],\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.258999992819,0.573000021542,0.647000002394,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"fl\",\"c\":{\"a\":0,\"k\":[0.713999968884,0.941000007181,1,1],\"ix\":4},\"o\":{\"a\":0,\"k\":100,\"ix\":5},\"r\":1,\"nm\":\"Fill 1\",\"mn\":\"ADBE Vector Graphic - Fill\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[150,143.582],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 11\",\"np\":3,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":0,\"op\":16,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":2,\"ty\":4,\"nm\":\"mailhigh Outlines - Group 12\",\"parent\":5,\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":0,\"k\":[150,156.418,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[150,156.418,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0],[0,0]],\"o\":[[0,0],[0,0],[0,0]],\"v\":[[-57.911,28.586],[0,-28.585],[57.91,28.586]],\"c\":true},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.258999992819,0.573000021542,0.647000002394,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"fl\",\"c\":{\"a\":0,\"k\":[0.713999968884,0.941000007181,1,1],\"ix\":4},\"o\":{\"a\":0,\"k\":100,\"ix\":5},\"r\":1,\"nm\":\"Fill 1\",\"mn\":\"ADBE Vector Graphic - Fill\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[150,156.418],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 12\",\"np\":3,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":0,\"op\":120,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":3,\"ty\":4,\"nm\":\"mailhigh Outlines - Group 13\",\"parent\":5,\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":0,\"k\":[150,150,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[150,150,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]],\"o\":[[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]],\"v\":[[57.911,35.004],[0.001,35.004],[-57.91,35.004],[-57.91,-35.003],[0.001,14.996],[57.911,-35.003]],\"c\":true},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.258999992819,0.573000021542,0.647000002394,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"fl\",\"c\":{\"a\":0,\"k\":[0.713999968884,0.941000007181,1,1],\"ix\":4},\"o\":{\"a\":0,\"k\":100,\"ix\":5},\"r\":1,\"nm\":\"Fill 1\",\"mn\":\"ADBE Vector Graphic - Fill\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[150,150],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 13\",\"np\":3,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":0,\"op\":120,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":4,\"ty\":4,\"nm\":\"Merged Shape Layer\",\"parent\":5,\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":1,\"k\":[{\"i\":{\"x\":0.065,\"y\":1},\"o\":{\"x\":0.639,\"y\":0},\"n\":\"0p065_1_0p639_0\",\"t\":20,\"s\":[150,149.757,0],\"e\":[150,121.369,0],\"to\":[0,-4.73129653930664,0],\"ti\":[0,4.73129653930664,0]},{\"t\":39}],\"ix\":2},\"a\":{\"a\":0,\"k\":[250,221.37,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[116.953,125.833],[138.288,125.833]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.259000003338,0.573000013828,0.647000014782,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 14\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[227.621,225.833],\"ix\":2},\"a\":{\"a\":0,\"k\":[127.621,125.833],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"mailhigh Outlines - Group 14\",\"np\":1,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"gr\",\"it\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[143.685,115.805],[158.87,115.805]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.259000003338,0.573000013828,0.647000014782,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 16\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[251.278,215.805],\"ix\":2},\"a\":{\"a\":0,\"k\":[151.278,115.805],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"mailhigh Outlines - Group 16\",\"np\":1,\"cix\":2,\"ix\":2,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"gr\",\"it\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[116.953,115.805],[138.288,115.805]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.259000003338,0.573000013828,0.647000014782,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 18\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[227.621,215.805],\"ix\":2},\"a\":{\"a\":0,\"k\":[127.621,115.805],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"mailhigh Outlines - Group 18\",\"np\":1,\"cix\":2,\"ix\":3,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"gr\",\"it\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[116.953,105.765],[170.416,105.765]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.259000003338,0.573000013828,0.647000014782,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 20\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[243.685,205.765],\"ix\":2},\"a\":{\"a\":0,\"k\":[143.685,105.765],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"mailhigh Outlines - Group 20\",\"np\":1,\"cix\":2,\"ix\":4,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"gr\",\"it\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0],[0,0],[0,0]],\"o\":[[0,0],[0,0],[0,0],[0,0]],\"v\":[[44.825,28.631],[-44.825,28.631],[-44.825,-28.631],[44.825,-28.631]],\"c\":true},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.259000003338,0.573000013828,0.647000014782,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"fl\",\"c\":{\"a\":0,\"k\":[1,1,1,1],\"ix\":4},\"o\":{\"a\":0,\"k\":100,\"ix\":5},\"r\":1,\"nm\":\"Fill 1\",\"mn\":\"ADBE Vector Graphic - Fill\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[150,121.369],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 22\",\"np\":3,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[250,221.37],\"ix\":2},\"a\":{\"a\":0,\"k\":[150,121.369],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"mailhigh Outlines - Group 22\",\"np\":1,\"cix\":2,\"ix\":5,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":0,\"op\":120,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":5,\"ty\":4,\"nm\":\"mailhigh Outlines - Group 23\",\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":1,\"k\":[{\"i\":{\"x\":[0.667],\"y\":[1]},\"o\":{\"x\":[0.333],\"y\":[0]},\"n\":[\"0p667_1_0p333_0\"],\"t\":0,\"s\":[-118],\"e\":[0]},{\"t\":11}],\"ix\":10},\"p\":{\"a\":0,\"k\":[250,221.415,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[150,121.415,0],\"ix\":1},\"s\":{\"a\":1,\"k\":[{\"i\":{\"x\":[0.255,0.255,0.667],\"y\":[2.029,2.029,1]},\"o\":{\"x\":[0.474,0.474,0.333],\"y\":[0,0,0]},\"n\":[\"0p255_2p029_0p474_0\",\"0p255_2p029_0p474_0\",\"0p667_1_0p333_0\"],\"t\":0,\"s\":[0,0,100],\"e\":[100,100,100]},{\"t\":20}],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":1,\"k\":[{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"n\":\"0p833_0p833_0p167_0p167\",\"t\":11,\"s\":[{\"i\":[[0,0],[0,0],[0,0],[0,0],[0,0]],\"o\":[[0,0],[0,0],[0,0],[0,0],[0,0]],\"v\":[[57.911,-6.418],[0.025,-6.475],[-57.91,-6.418],[-57.91,63.589],[57.911,63.589]],\"c\":true}],\"e\":[{\"i\":[[0,0],[0,0],[0,0],[0,0],[0,0]],\"o\":[[0,0],[0,0],[0,0],[0,0],[0,0]],\"v\":[[57.911,-6.418],[0.025,-6.475],[-57.91,-6.418],[-57.91,63.589],[57.911,63.589]],\"c\":true}]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"n\":\"0p833_0p833_0p167_0p167\",\"t\":15,\"s\":[{\"i\":[[0,0],[0,0],[0,0],[0,0],[0,0]],\"o\":[[0,0],[0,0],[0,0],[0,0],[0,0]],\"v\":[[57.911,-6.418],[0.025,-6.475],[-57.91,-6.418],[-57.91,63.589],[57.911,63.589]],\"c\":true}],\"e\":[{\"i\":[[0,0],[0,0],[0,0],[0,0],[0,0]],\"o\":[[0,0],[0,0],[0,0],[0,0],[0,0]],\"v\":[[57.911,-6.418],[0.04,-62.827],[-57.91,-6.418],[-57.91,63.589],[57.911,63.589]],\"c\":true}]},{\"t\":16}],\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.258999992819,0.573000021542,0.647000002394,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"fl\",\"c\":{\"a\":0,\"k\":[0.4,0.736999990426,0.827000038297,1],\"ix\":4},\"o\":{\"a\":0,\"k\":100,\"ix\":5},\"r\":1,\"nm\":\"Fill 1\",\"mn\":\"ADBE Vector Graphic - Fill\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[150,121.415],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 23\",\"np\":3,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":0,\"op\":120,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":6,\"ty\":4,\"nm\":\"mailhigh Outlines - Group 9\",\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":1,\"k\":[{\"i\":{\"x\":0,\"y\":1},\"o\":{\"x\":0.726,\"y\":0},\"n\":\"0_1_0p726_0\",\"t\":20,\"s\":[206.415,237.268,0],\"e\":[158.915,250.268,0],\"to\":[-7.91666650772095,2.16666674613953,0],\"ti\":[7.91666650772095,-2.16666674613953,0]},{\"t\":35}],\"ix\":2},\"a\":{\"a\":0,\"k\":[58.915,150.268,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0],[-0.866,0.726],[-0.725,-0.866],[0,0],[1.891,-1.585],[1.585,1.89],[0,0],[-1.89,1.585],[-1.584,-1.891],[0,0]],\"o\":[[0,0],[-0.725,-0.866],[0.866,-0.725],[0,0],[1.584,1.891],[-1.891,1.584],[0,0],[-1.584,-1.891],[1.892,-1.585],[0,0],[0,0]],\"v\":[[4.299,4.543],[0.281,-0.25],[0.535,-3.132],[3.416,-2.878],[8.022,2.617],[7.467,8.91],[1.174,8.356],[-8.022,-2.616],[-7.468,-8.909],[-1.175,-8.355],[0.986,-5.776]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.258999992819,0.573000021542,0.647000002394,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[58.915,150.268],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 9\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":18,\"op\":120,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":7,\"ty\":4,\"nm\":\"mailhigh Outlines - Group 10\",\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":1,\"k\":[{\"i\":{\"x\":0,\"y\":1},\"o\":{\"x\":0.726,\"y\":0},\"n\":\"0_1_0p726_0\",\"t\":20,\"s\":[288.708,226.722,0],\"e\":[327.708,186.222,0],\"to\":[6.5,-6.75,0],\"ti\":[-6.5,6.75,0]},{\"t\":35}],\"ix\":2},\"a\":{\"a\":0,\"k\":[227.708,86.222,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0],[1.185,0.615],[0.615,-1.184],[0,0],[-2.586,-1.343],[-1.343,2.587],[0,0],[2.587,1.343],[1.344,-2.587],[0,0]],\"o\":[[0,0],[0.615,-1.184],[-1.184,-0.615],[0,0],[-1.343,2.587],[2.587,1.343],[0,0],[1.344,-2.587],[-2.587,-1.344],[0,0],[0,0]],\"v\":[[-3.795,6.341],[-0.389,-0.217],[-1.42,-3.475],[-4.678,-2.444],[-8.582,5.073],[-6.331,12.189],[0.785,9.938],[8.581,-5.072],[6.33,-12.188],[-0.786,-9.937],[-2.618,-6.409]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.258999992819,0.573000021542,0.647000002394,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[227.708,86.222],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 10\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":18,\"op\":120,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":8,\"ty\":4,\"nm\":\"mailhigh Outlines - Group 1\",\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":1,\"k\":[{\"i\":{\"x\":0.667,\"y\":1},\"o\":{\"x\":0.333,\"y\":0},\"n\":\"0p667_1_0p333_0\",\"t\":20,\"s\":[203.48,264.31,0],\"e\":[167.98,291.56,0],\"to\":[-5.91666650772095,4.54166650772095,0],\"ti\":[5.91666650772095,-4.54166650772095,0]},{\"t\":35}],\"ix\":2},\"a\":{\"a\":0,\"k\":[67.98,191.561,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,-1.97],[1.969,0],[0,1.97],[-1.97,0]],\"o\":[[0,1.97],[-1.97,0],[0,-1.97],[1.969,0]],\"v\":[[3.567,0],[0.001,3.566],[-3.566,0],[0.001,-3.566]],\"c\":true},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.4,0.736999990426,0.827000038297,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[67.98,191.561],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 1\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":18,\"op\":120,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":9,\"ty\":4,\"nm\":\"mailhigh Outlines - Group 2\",\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":1,\"k\":[{\"i\":{\"x\":0.667,\"y\":1},\"o\":{\"x\":0.333,\"y\":0},\"n\":\"0p667_1_0p333_0\",\"t\":20,\"s\":[260.323,213.223,0],\"e\":[289.073,173.473,0],\"to\":[4.79166650772095,-6.625,0],\"ti\":[-4.79166650772095,6.625,0]},{\"t\":35}],\"ix\":2},\"a\":{\"a\":0,\"k\":[189.073,73.473,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,-1.969],[1.969,0],[0,1.97],[-1.97,0]],\"o\":[[0,1.97],[-1.97,0],[0,-1.969],[1.969,0]],\"v\":[[3.567,0],[0.001,3.566],[-3.566,0],[0.001,-3.566]],\"c\":true},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.4,0.736999990426,0.827000038297,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[189.073,73.473],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 2\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":18,\"op\":120,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":10,\"ty\":4,\"nm\":\"Merged Shape Layer\",\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":1,\"k\":[{\"i\":{\"x\":0.667,\"y\":1},\"o\":{\"x\":0.333,\"y\":0},\"n\":\"0p667_1_0p333_0\",\"t\":20,\"s\":[288.383,235.417,0],\"e\":[332.633,252.167,0],\"to\":[7.375,2.79166674613953,0],\"ti\":[-7.375,-2.79166674613953,0]},{\"t\":35}],\"ix\":2},\"a\":{\"a\":0,\"k\":[332.633,252.167,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[236.885,152.167],[228.381,152.167]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.40000000596,0.736999988556,0.827000021935,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 3\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[332.633,252.167],\"ix\":2},\"a\":{\"a\":0,\"k\":[232.633,152.167],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"mailhigh Outlines - Group 3\",\"np\":1,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"gr\",\"it\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[232.633,147.915],[232.633,156.418]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.40000000596,0.736999988556,0.827000021935,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 4\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[332.633,252.167],\"ix\":2},\"a\":{\"a\":0,\"k\":[232.633,152.167],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"mailhigh Outlines - Group 4\",\"np\":1,\"cix\":2,\"ix\":2,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":18,\"op\":120,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":11,\"ty\":4,\"nm\":\"Merged Shape Layer\",\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":1,\"k\":[{\"i\":{\"x\":0.667,\"y\":1},\"o\":{\"x\":0.333,\"y\":0},\"n\":\"0p667_1_0p333_0\",\"t\":20,\"s\":[232.783,274.771,0],\"e\":[225.033,304.771,0],\"to\":[-1.29166662693024,5,0],\"ti\":[1.29166662693024,-5,0]},{\"t\":35}],\"ix\":2},\"a\":{\"a\":0,\"k\":[225.033,304.771,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[129.284,204.771],[120.781,204.771]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.40000000596,0.736999988556,0.827000021935,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 5\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[225.033,304.771],\"ix\":2},\"a\":{\"a\":0,\"k\":[125.033,204.771],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"mailhigh Outlines - Group 5\",\"np\":1,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"gr\",\"it\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[125.032,200.52],[125.032,209.023]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.40000000596,0.736999988556,0.827000021935,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 6\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[225.032,304.771],\"ix\":2},\"a\":{\"a\":0,\"k\":[125.032,204.771],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"mailhigh Outlines - Group 6\",\"np\":1,\"cix\":2,\"ix\":2,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":18,\"op\":120,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":12,\"ty\":4,\"nm\":\"Merged Shape Layer\",\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":1,\"k\":[{\"i\":{\"x\":0.667,\"y\":1},\"o\":{\"x\":0.333,\"y\":0},\"n\":\"0p667_1_0p333_0\",\"t\":20,\"s\":[210.772,209.677,0],\"e\":[181.522,188.177,0],\"to\":[-4.875,-3.58333325386047,0],\"ti\":[4.875,3.58333325386047,0]},{\"t\":35}],\"ix\":2},\"a\":{\"a\":0,\"k\":[181.522,188.177,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[85.773,88.177],[77.27,88.177]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.40000000596,0.736999988556,0.827000021935,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 7\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[181.522,188.177],\"ix\":2},\"a\":{\"a\":0,\"k\":[81.522,88.177],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"mailhigh Outlines - Group 7\",\"np\":1,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"gr\",\"it\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[81.521,83.925],[81.521,92.428]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.40000000596,0.736999988556,0.827000021935,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":2,\"ix\":5},\"lc\":1,\"lj\":2,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[0,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 8\",\"np\":2,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[181.521,188.177],\"ix\":2},\"a\":{\"a\":0,\"k\":[81.521,88.177],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"mailhigh Outlines - Group 8\",\"np\":1,\"cix\":2,\"ix\":2,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":18,\"op\":120,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":13,\"ty\":4,\"nm\":\"mailhigh Outlines - Group 25\",\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":0,\"k\":[240.685,253.315,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[143.685,140.315,0],\"ix\":1},\"s\":{\"a\":1,\"k\":[{\"i\":{\"x\":[0.185,0.185,0.667],\"y\":[1,1,1]},\"o\":{\"x\":[0.648,0.648,0.333],\"y\":[0,0,0]},\"n\":[\"0p185_1_0p648_0\",\"0p185_1_0p648_0\",\"0p667_1_0p333_0\"],\"t\":18,\"s\":[0,0,100],\"e\":[100,100,100]},{\"t\":29}],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,-40.549],[41.551,0],[0,40.548],[-41.552,0]],\"o\":[[0,40.548],[-41.552,0],[0,-40.549],[41.551,0]],\"v\":[[75.236,0],[0,73.42],[-75.236,0],[0,-73.42]],\"c\":true},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"mm\",\"mm\":4,\"nm\":\"Merge Paths 1\",\"mn\":\"ADBE Vector Filter - Merge\",\"hd\":false},{\"ty\":\"fl\",\"c\":{\"a\":0,\"k\":[0.88371629902,0.976011388442,1,1],\"ix\":4},\"o\":{\"a\":0,\"k\":100,\"ix\":5},\"r\":1,\"nm\":\"Fill 1\",\"mn\":\"ADBE Vector Graphic - Fill\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[143.685,140.315],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 24\",\"np\":3,\"cix\":2,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":18,\"op\":120,\"st\":0,\"bm\":0}],\"markers\":[]}");

/***/ }),

/***/ "4Q3z":
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ 5:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("ZbNj");


/***/ }),

/***/ "6D7l":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.formatUrl = formatUrl;

var querystring = _interopRequireWildcard(__webpack_require__("3WeD"));

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
} // Format function modified from nodejs
// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


const slashedProtocols = /https?|ftp|gopher|file/;

function formatUrl(urlObj) {
  let {
    auth,
    hostname
  } = urlObj;
  let protocol = urlObj.protocol || '';
  let pathname = urlObj.pathname || '';
  let hash = urlObj.hash || '';
  let query = urlObj.query || '';
  let host = false;
  auth = auth ? encodeURIComponent(auth).replace(/%3A/i, ':') + '@' : '';

  if (urlObj.host) {
    host = auth + urlObj.host;
  } else if (hostname) {
    host = auth + (~hostname.indexOf(':') ? `[${hostname}]` : hostname);

    if (urlObj.port) {
      host += ':' + urlObj.port;
    }
  }

  if (query && typeof query === 'object') {
    query = String(querystring.urlQueryToSearchParams(query));
  }

  let search = urlObj.search || query && `?${query}` || '';
  if (protocol && protocol.substr(-1) !== ':') protocol += ':';

  if (urlObj.slashes || (!protocol || slashedProtocols.test(protocol)) && host !== false) {
    host = '//' + (host || '');
    if (pathname && pathname[0] !== '/') pathname = '/' + pathname;
  } else if (!host) {
    host = '';
  }

  if (hash && hash[0] !== '#') hash = '#' + hash;
  if (search && search[0] !== '?') search = '?' + search;
  pathname = pathname.replace(/[?#]/g, encodeURIComponent);
  search = search.replace('#', '%23');
  return `${protocol}${host}${pathname}${search}${hash}`;
}

/***/ }),

/***/ "99J/":
/***/ (function(module, exports) {

module.exports = require("react-multi-carousel");

/***/ }),

/***/ "C8TP":
/***/ (function(module, exports) {

module.exports = require("yup");

/***/ }),

/***/ "F5FC":
/***/ (function(module, exports) {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "IZS3":
/***/ (function(module, exports) {

module.exports = require("react-bootstrap");

/***/ }),

/***/ "IrP5":
/***/ (function(module, exports) {

module.exports = require("react-reveal/Fade");

/***/ }),

/***/ "JVe5":
/***/ (function(module, exports) {

module.exports = require("@fortawesome/free-brands-svg-icons");

/***/ }),

/***/ "Nh2W":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("TqRt");

exports.__esModule = true;
exports.markAssetError = markAssetError;
exports.isAssetError = isAssetError;
exports.getClientBuildManifest = getClientBuildManifest;
exports.default = void 0;

var _getAssetPathFromRoute = _interopRequireDefault(__webpack_require__("UhrY"));

var _requestIdleCallback = _interopRequireDefault(__webpack_require__("0G5g")); // 3.8s was arbitrarily chosen as it's what https://web.dev/interactive
// considers as "Good" time-to-interactive. We must assume something went
// wrong beyond this point, and then fall-back to a full page transition to
// show the user something of value.


const MS_MAX_IDLE_DELAY = 3800;

function withFuture(key, map, generator) {
  let entry = map.get(key);

  if (entry) {
    if ('future' in entry) {
      return entry.future;
    }

    return Promise.resolve(entry);
  }

  let resolver;
  const prom = new Promise(resolve => {
    resolver = resolve;
  });
  map.set(key, entry = {
    resolve: resolver,
    future: prom
  });
  return generator ? // eslint-disable-next-line no-sequences
  generator().then(value => (resolver(value), value)) : prom;
}

function hasPrefetch(link) {
  try {
    link = document.createElement('link');
    return (// detect IE11 since it supports prefetch but isn't detected
      // with relList.support
      !!window.MSInputMethodContext && !!document.documentMode || link.relList.supports('prefetch')
    );
  } catch (_unused) {
    return false;
  }
}

const canPrefetch = hasPrefetch();

function prefetchViaDom(href, as, link) {
  return new Promise((res, rej) => {
    if (document.querySelector(`link[rel="prefetch"][href^="${href}"]`)) {
      return res();
    }

    link = document.createElement('link'); // The order of property assignment here is intentional:

    if (as) link.as = as;
    link.rel = `prefetch`;
    link.crossOrigin = undefined;
    link.onload = res;
    link.onerror = rej; // `href` should always be last:

    link.href = href;
    document.head.appendChild(link);
  });
}

const ASSET_LOAD_ERROR = Symbol('ASSET_LOAD_ERROR'); // TODO: unexport

function markAssetError(err) {
  return Object.defineProperty(err, ASSET_LOAD_ERROR, {});
}

function isAssetError(err) {
  return err && ASSET_LOAD_ERROR in err;
}

function appendScript(src, script) {
  return new Promise((resolve, reject) => {
    script = document.createElement('script'); // The order of property assignment here is intentional.
    // 1. Setup success/failure hooks in case the browser synchronously
    //    executes when `src` is set.

    script.onload = resolve;

    script.onerror = () => reject(markAssetError(new Error(`Failed to load script: ${src}`))); // 2. Configure the cross-origin attribute before setting `src` in case the
    //    browser begins to fetch.


    script.crossOrigin = undefined; // 3. Finally, set the source and inject into the DOM in case the child
    //    must be appended for fetching to start.

    script.src = src;
    document.body.appendChild(script);
  });
}

function idleTimeout(ms, err) {
  return new Promise((_resolve, reject) => (0, _requestIdleCallback.default)(() => setTimeout(() => reject(err), ms)));
} // TODO: stop exporting or cache the failure
// It'd be best to stop exporting this. It's an implementation detail. We're
// only exporting it for backwards compatibilty with the `page-loader`.
// Only cache this response as a last resort if we cannot eliminate all other
// code branches that use the Build Manifest Callback and push them through
// the Route Loader interface.


function getClientBuildManifest() {
  if (self.__BUILD_MANIFEST) {
    return Promise.resolve(self.__BUILD_MANIFEST);
  }

  const onBuildManifest = new Promise(resolve => {
    // Mandatory because this is not concurrent safe:
    const cb = self.__BUILD_MANIFEST_CB;

    self.__BUILD_MANIFEST_CB = () => {
      resolve(self.__BUILD_MANIFEST);
      cb && cb();
    };
  });
  return Promise.race([onBuildManifest, idleTimeout(MS_MAX_IDLE_DELAY, markAssetError(new Error('Failed to load client build manifest')))]);
}

function getFilesForRoute(assetPrefix, route) {
  if (false) {}

  return getClientBuildManifest().then(manifest => {
    if (!(route in manifest)) {
      throw markAssetError(new Error(`Failed to lookup route: ${route}`));
    }

    const allFiles = manifest[route].map(entry => assetPrefix + '/_next/' + encodeURI(entry));
    return {
      scripts: allFiles.filter(v => v.endsWith('.js')),
      css: allFiles.filter(v => v.endsWith('.css'))
    };
  });
}

function createRouteLoader(assetPrefix) {
  const entrypoints = new Map();
  const loadedScripts = new Map();
  const styleSheets = new Map();
  const routes = new Map();

  function maybeExecuteScript(src) {
    let prom = loadedScripts.get(src);

    if (prom) {
      return prom;
    } // Skip executing script if it's already in the DOM:


    if (document.querySelector(`script[src^="${src}"]`)) {
      return Promise.resolve();
    }

    loadedScripts.set(src, prom = appendScript(src));
    return prom;
  }

  function fetchStyleSheet(href) {
    let prom = styleSheets.get(href);

    if (prom) {
      return prom;
    }

    styleSheets.set(href, prom = fetch(href).then(res => {
      if (!res.ok) {
        throw new Error(`Failed to load stylesheet: ${href}`);
      }

      return res.text().then(text => ({
        href: href,
        content: text
      }));
    }).catch(err => {
      throw markAssetError(err);
    }));
    return prom;
  }

  return {
    whenEntrypoint(route) {
      return withFuture(route, entrypoints);
    },

    onEntrypoint(route, execute) {
      Promise.resolve(execute).then(fn => fn()).then(exports => ({
        component: exports && exports.default || exports,
        exports: exports
      }), err => ({
        error: err
      })).then(input => {
        const old = entrypoints.get(route);
        entrypoints.set(route, input);
        if (old && 'resolve' in old) old.resolve(input);
      });
    },

    loadRoute(route) {
      return withFuture(route, routes, async () => {
        try {
          const {
            scripts,
            css
          } = await getFilesForRoute(assetPrefix, route);
          const [, styles] = await Promise.all([entrypoints.has(route) ? [] : Promise.all(scripts.map(maybeExecuteScript)), Promise.all(css.map(fetchStyleSheet))]);
          const entrypoint = await Promise.race([this.whenEntrypoint(route), idleTimeout(MS_MAX_IDLE_DELAY, markAssetError(new Error(`Route did not complete loading: ${route}`)))]);
          const res = Object.assign({
            styles
          }, entrypoint);
          return 'error' in entrypoint ? entrypoint : res;
        } catch (err) {
          return {
            error: err
          };
        }
      });
    },

    prefetch(route) {
      // https://github.com/GoogleChromeLabs/quicklink/blob/453a661fa1fa940e2d2e044452398e38c67a98fb/src/index.mjs#L115-L118
      // License: Apache 2.0
      let cn;

      if (cn = navigator.connection) {
        // Don't prefetch if using 2G or if Save-Data is enabled.
        if (cn.saveData || /2g/.test(cn.effectiveType)) return Promise.resolve();
      }

      return getFilesForRoute(assetPrefix, route).then(output => Promise.all(canPrefetch ? output.scripts.map(script => prefetchViaDom(script, 'script')) : [])).then(() => {
        (0, _requestIdleCallback.default)(() => this.loadRoute(route));
      }).catch( // swallow prefetch errors
      () => {});
    }

  };
}

var _default = createRouteLoader;
exports.default = _default;

/***/ }),

/***/ "No/t":
/***/ (function(module, exports) {

module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ "Osoz":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/router-context.js");

/***/ }),

/***/ "QMtg":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return defaultLocal; });
/* unused harmony export locals */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LanguageContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return LanguageProvider; });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("F5FC");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const defaultLocal = "en";
const locals = ["en", "ar"];
const LanguageContext = /*#__PURE__*/Object(react__WEBPACK_IMPORTED_MODULE_1__["createContext"])([]);
const LanguageProvider = ({
  children
}) => {
  let lang;

  if (typeof Storage !== "undefined") {
    lang = localStorage.getItem('lang');
  }

  const {
    0: locale,
    1: setLocale
  } = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(lang ? lang : "en");
  return /*#__PURE__*/Object(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__["jsx"])(LanguageContext.Provider, {
    value: [locale, setLocale],
    children: children
  });
};

/***/ }),

/***/ "QVBc":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"aboutHome": "aboutHome_aboutHome__u84Zv",
	"container": "aboutHome_container__1DV3b"
};


/***/ }),

/***/ "QxnH":
/***/ (function(module, exports) {

module.exports = require("formik");

/***/ }),

/***/ "RdaU":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"componentContainer": "upload_componentContainer__1X8_F",
	"uploadDiv": "upload_uploadDiv__18dIf",
	"imgInput": "upload_imgInput__26tAy"
};


/***/ }),

/***/ "S3md":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/***/ }),

/***/ "TqRt":
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "UhrY":
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ "VLDe":
/***/ (function(module, exports) {



/***/ }),

/***/ "X24+":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.removePathTrailingSlash = removePathTrailingSlash;
exports.normalizePathTrailingSlash = void 0;
/**
* Removes the trailing slash of a path if there is one. Preserves the root path `/`.
*/

function removePathTrailingSlash(path) {
  return path.endsWith('/') && path !== '/' ? path.slice(0, -1) : path;
}
/**
* Normalizes the trailing slash of a path according to the `trailingSlash` option
* in `next.config.js`.
*/


const normalizePathTrailingSlash =  false ? undefined : removePathTrailingSlash;
exports.normalizePathTrailingSlash = normalizePathTrailingSlash;

/***/ }),

/***/ "YFqc":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("cTJO")


/***/ }),

/***/ "YTqd":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteRegex = getRouteRegex; // this isn't importing the escape-string-regex module
// to reduce bytes

function escapeRegex(str) {
  return str.replace(/[|\\{}()[\]^$+*?.-]/g, '\\$&');
}

function parseParameter(param) {
  const optional = param.startsWith('[') && param.endsWith(']');

  if (optional) {
    param = param.slice(1, -1);
  }

  const repeat = param.startsWith('...');

  if (repeat) {
    param = param.slice(3);
  }

  return {
    key: param,
    repeat,
    optional
  };
}

function getRouteRegex(normalizedRoute) {
  const segments = (normalizedRoute.replace(/\/$/, '') || '/').slice(1).split('/');
  const groups = {};
  let groupIndex = 1;
  const parameterizedRoute = segments.map(segment => {
    if (segment.startsWith('[') && segment.endsWith(']')) {
      const {
        key,
        optional,
        repeat
      } = parseParameter(segment.slice(1, -1));
      groups[key] = {
        pos: groupIndex++,
        repeat,
        optional
      };
      return repeat ? optional ? '(?:/(.+?))?' : '/(.+?)' : '/([^/]+?)';
    } else {
      return `/${escapeRegex(segment)}`;
    }
  }).join(''); // dead code eliminate for browser since it's only needed
  // while generating routes-manifest

  if (true) {
    let routeKeyCharCode = 97;
    let routeKeyCharLength = 1; // builds a minimal routeKey using only a-z and minimal number of characters

    const getSafeRouteKey = () => {
      let routeKey = '';

      for (let i = 0; i < routeKeyCharLength; i++) {
        routeKey += String.fromCharCode(routeKeyCharCode);
        routeKeyCharCode++;

        if (routeKeyCharCode > 122) {
          routeKeyCharLength++;
          routeKeyCharCode = 97;
        }
      }

      return routeKey;
    };

    const routeKeys = {};
    let namedParameterizedRoute = segments.map(segment => {
      if (segment.startsWith('[') && segment.endsWith(']')) {
        const {
          key,
          optional,
          repeat
        } = parseParameter(segment.slice(1, -1)); // replace any non-word characters since they can break
        // the named regex

        let cleanedKey = key.replace(/\W/g, '');
        let invalidKey = false; // check if the key is still invalid and fallback to using a known
        // safe key

        if (cleanedKey.length === 0 || cleanedKey.length > 30) {
          invalidKey = true;
        }

        if (!isNaN(parseInt(cleanedKey.substr(0, 1)))) {
          invalidKey = true;
        }

        if (invalidKey) {
          cleanedKey = getSafeRouteKey();
        }

        routeKeys[cleanedKey] = key;
        return repeat ? optional ? `(?:/(?<${cleanedKey}>.+?))?` : `/(?<${cleanedKey}>.+?)` : `/(?<${cleanedKey}>[^/]+?)`;
      } else {
        return `/${escapeRegex(segment)}`;
      }
    }).join('');
    return {
      re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
      groups,
      routeKeys,
      namedRegex: `^${namedParameterizedRoute}(?:/)?$`
    };
  }

  return {
    re: new RegExp(`^${parameterizedRoute}(?:/)?$`),
    groups
  };
}

/***/ }),

/***/ "ZbNj":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, "default", function() { return /* binding */ CategoriesAdmin; });
__webpack_require__.d(__webpack_exports__, "getServerSideProps", function() { return /* binding */ getServerSideProps; });

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// EXTERNAL MODULE: ./components/index.tsx + 36 modules
var components = __webpack_require__("m/eG");

// EXTERNAL MODULE: ./locals/localHook.tsx + 1 modules
var localHook = __webpack_require__("04F5");

// CONCATENATED MODULE: ./reducers/categories/reducer.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

const categoriesReducer = (state = [], action) => {
  switch (action.type) {
    case "ADD_CATEGORY":
      return [...state, action.category];

    case "EDIT_CATEGORY":
      return state.map(category => {
        if (category.id === action.id) {
          return _objectSpread(_objectSpread({}, category), action.category);
        } else {
          return category;
        }
      });

    case "SET_CATEGORIES":
      return action.categories;

    default:
      return state;
  }
};

/* harmony default export */ var reducer = (categoriesReducer);
// CONCATENATED MODULE: ./reducers/categories/actions.ts
const addCategory = category => ({
  type: "ADD_CATEGORY",
  category
});
const editCategory = (id, category) => ({
  type: "EDIT_CATEGORY",
  id,
  category
});
const setCategories = categories => ({
  type: "SET_CATEGORIES",
  categories
});
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");
var router_default = /*#__PURE__*/__webpack_require__.n(router_);

// CONCATENATED MODULE: ./pages/admin/categories.tsx



function categories_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function categories_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { categories_ownKeys(Object(source), true).forEach(function (key) { categories_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { categories_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function categories_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }







function CategoriesAdmin({
  categories
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  const {
    0: allCategories,
    1: dispatchCategories
  } = Object(external_react_["useReducer"])(reducer, categories ? categories.map(d => ({
    id: d.id,
    title: d.title,
    title_ar: d.title_ar,
    createdAt: d.created_at,
    updatedAt: d.updated_at,
    isDeleted: d.isDeleted
  })) : []);
  const {
    0: filteredCategories,
    1: setFilteredCategories
  } = Object(external_react_["useState"])(allCategories.filter(category => !category.isDeleted));
  const {
    0: filterDelete,
    1: setFilterDelete
  } = Object(external_react_["useState"])("false");
  const {
    0: modalType,
    1: setModalType
  } = Object(external_react_["useState"])("add");
  const {
    0: selected,
    1: setSelected
  } = Object(external_react_["useState"])();
  const {
    0: show,
    1: setShow
  } = Object(external_react_["useState"])(false);
  const filterRef = Object(external_react_["useRef"])();
  let tableTitles = ['#', t('Title'), t('ArTitle'), t('CrDate'), t('UpDate'), ''];

  const editFetch = async values => {
    try {
      const res = await fetch('/api/categories/edit', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          id: values.id,
          title: values.title,
          title_ar: values.title_ar,
          isDeleted: values.isDeleted
        })
      });
      const json = await res.json();
      if (!res.ok) throw Error(json.message);
      dispatchCategories(editCategory(values.id, categories_objectSpread(categories_objectSpread({}, values), {}, {
        isDeleted: values.isDeleted
      })));
      handleClose();
    } catch (e) {
      throw Error(e.message);
    }
  };

  const handleClose = () => setShow(false);

  const handleShow = () => setShow(true);

  const confirmDelete = () => {
    /// API for Edit
    editFetch(categories_objectSpread(categories_objectSpread({}, selected), {}, {
      isDeleted: 1
    }));
  };

  const restoreItem = item => {
    /// API for Edit
    editFetch(categories_objectSpread(categories_objectSpread({}, item), {}, {
      isDeleted: 0
    }));
  };

  const editItem = item => {
    /// API for Edit
    editFetch(categories_objectSpread({}, item));
  };

  const addItem = async item => {
    /// API for Add
    try {
      const res = await fetch('/api/categories/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title: item.title,
          title_ar: item.title_ar,
          isDeleted: 0
        })
      });
      const json = await res.json();
      if (!res.ok) throw Error(json.message);
      dispatchCategories(addCategory(categories_objectSpread({
        id: json.insertId
      }, item)));
      handleClose();
    } catch (e) {
      throw Error(e.message);
    }
  };

  const handleAdd = () => {
    setModalType("add");
    handleShow();
  };

  const handleDelete = item => {
    setModalType("delete");
    handleShow();
    setSelected(item);
  };

  const handleEdit = item => {
    setModalType("edit");
    handleShow();
    setSelected(item);
  };

  const filterChange = () => {
    var _filterRef$current;

    const selectedVal = filterRef === null || filterRef === void 0 ? void 0 : (_filterRef$current = filterRef.current) === null || _filterRef$current === void 0 ? void 0 : _filterRef$current.value;
    setFilterDelete(selectedVal);

    if (selectedVal === "true") {
      setFilteredCategories(allCategories.filter(category => category.isDeleted === 1));
    } else if (selectedVal === "false") {
      setFilteredCategories(allCategories.filter(category => category.isDeleted === 0));
    } else {
      setFilteredCategories(allCategories);
    }
  };

  Object(external_react_["useEffect"])(() => {
    filterChange();
  }, [allCategories]);
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(components["e" /* AdminLayout */], {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(components["g" /* AdminSectionHeader */], {
      sectionName: t("Categories"),
      handleAdd: handleAdd
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("hr", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])(components["b" /* AdmenFilterByDelete */], {
      filterRef: filterRef,
      filterDelete: filterDelete,
      filterChange: filterChange
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("hr", {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])(components["h" /* AdminTable */], {
      tableTitles: tableTitles,
      items: filteredCategories,
      handleDelete: handleDelete,
      restoreItem: restoreItem,
      handleEdit: handleEdit
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(components["f" /* AdminModal */], {
      show: show,
      handleClose: handleClose,
      formTitle: modalType === 'delete' ? t('Delete') : modalType === 'edit' ? t('Edit') : t('Add'),
      FormComponent: modalType === 'delete' ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(components["m" /* ConfirmDelete */], {
        confirmDelete: confirmDelete,
        handleClose: handleClose
      }) : modalType === 'edit' ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(components["k" /* CategoryForm */], {
        type: modalType,
        item: selected,
        addItem: addItem,
        editItem: editItem,
        handleClose: handleClose
      }) : /*#__PURE__*/Object(jsx_runtime_["jsx"])(components["k" /* CategoryForm */], {
        type: modalType,
        item: {},
        addItem: addItem,
        editItem: editItem,
        handleClose: handleClose
      })
    })]
  });
}
async function getServerSideProps(ctx) {
  var _ctx$req;

  const cookie = (_ctx$req = ctx.req) === null || _ctx$req === void 0 ? void 0 : _ctx$req.headers.cookie;
  const url = `${process.env.URL_ROOT}/api/categories/all`;
  const resp = await fetch(url);

  if (resp.status === 401 && !ctx.req) {
    router_default.a.replace('/admin/login');
    return {
      props: {}
    };
  }

  if (resp.status === 401 && ctx.req) {
    var _ctx$res, _ctx$res2;

    (_ctx$res = ctx.res) === null || _ctx$res === void 0 ? void 0 : _ctx$res.writeHead(302, {
      Location: `${process.env.URL_ROOT}/admin/login`
    });
    (_ctx$res2 = ctx.res) === null || _ctx$res2 === void 0 ? void 0 : _ctx$res2.end();
    return {
      props: {}
    };
  }

  const categories = await resp.json();
  return {
    props: {
      categories: categories ? categories : []
    }
  };
}

/***/ }),

/***/ "aYjl":
/***/ (function(module, exports) {

module.exports = require("swr");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "cDf5":
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "cTJO":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__("284h");

exports.__esModule = true;
exports.default = void 0;

var _react = _interopRequireWildcard(__webpack_require__("cDcd"));

var _router = __webpack_require__("elyg");

var _router2 = __webpack_require__("nOHt");

var _useIntersection = __webpack_require__("vNVm");

const prefetched = {};

function prefetch(router, href, as, options) {
  if (true) return;
  if (!(0, _router.isLocalURL)(href)) return; // Prefetch the JSON page if asked (only in the client)
  // We need to handle a prefetch error here since we may be
  // loading with priority which can reject but we don't
  // want to force navigation since this is only a prefetch

  router.prefetch(href, as, options).catch(err => {
    if (false) {}
  });
  const curLocale = options && typeof options.locale !== 'undefined' ? options.locale : router && router.locale; // Join on an invalid URI character

  prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')] = true;
}

function isModifiedEvent(event) {
  const {
    target
  } = event.currentTarget;
  return target && target !== '_self' || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || // triggers resource download
  event.nativeEvent && event.nativeEvent.which === 2;
}

function linkClicked(e, router, href, as, replace, shallow, scroll, locale) {
  const {
    nodeName
  } = e.currentTarget;

  if (nodeName === 'A' && (isModifiedEvent(e) || !(0, _router.isLocalURL)(href))) {
    // ignore click for browser’s default behavior
    return;
  }

  e.preventDefault(); //  avoid scroll for urls with anchor refs

  if (scroll == null) {
    scroll = as.indexOf('#') < 0;
  } // replace state instead of push if prop is present


  router[replace ? 'replace' : 'push'](href, as, {
    shallow,
    locale
  }).then(success => {
    if (!success) return;

    if (scroll) {
      window.scrollTo(0, 0);
      document.body.focus();
    }
  });
}

function Link(props) {
  if (false) {}

  const p = props.prefetch !== false;
  const router = (0, _router2.useRouter)();
  const pathname = router && router.pathname || '/';

  const {
    href,
    as
  } = _react.default.useMemo(() => {
    const [resolvedHref, resolvedAs] = (0, _router.resolveHref)(pathname, props.href, true);
    return {
      href: resolvedHref,
      as: props.as ? (0, _router.resolveHref)(pathname, props.as) : resolvedAs || resolvedHref
    };
  }, [pathname, props.href, props.as]);

  let {
    children,
    replace,
    shallow,
    scroll,
    locale
  } = props; // Deprecated. Warning shown by propType check. If the children provided is a string (<Link>example</Link>) we wrap it in an <a> tag

  if (typeof children === 'string') {
    children = /*#__PURE__*/_react.default.createElement("a", null, children);
  } // This will return the first child, if multiple are provided it will throw an error


  const child = _react.Children.only(children);

  const childRef = child && typeof child === 'object' && child.ref;
  const [setIntersectionRef, isVisible] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px'
  });

  const setRef = _react.default.useCallback(el => {
    setIntersectionRef(el);

    if (childRef) {
      if (typeof childRef === 'function') childRef(el);else if (typeof childRef === 'object') {
        childRef.current = el;
      }
    }
  }, [childRef, setIntersectionRef]);

  (0, _react.useEffect)(() => {
    const shouldPrefetch = isVisible && p && (0, _router.isLocalURL)(href);
    const curLocale = typeof locale !== 'undefined' ? locale : router && router.locale;
    const isPrefetched = prefetched[href + '%' + as + (curLocale ? '%' + curLocale : '')];

    if (shouldPrefetch && !isPrefetched) {
      prefetch(router, href, as, {
        locale: curLocale
      });
    }
  }, [as, href, isVisible, locale, p, router]);
  const childProps = {
    ref: setRef,
    onClick: e => {
      if (child.props && typeof child.props.onClick === 'function') {
        child.props.onClick(e);
      }

      if (!e.defaultPrevented) {
        linkClicked(e, router, href, as, replace, shallow, scroll, locale);
      }
    }
  };

  childProps.onMouseEnter = e => {
    if (!(0, _router.isLocalURL)(href)) return;

    if (child.props && typeof child.props.onMouseEnter === 'function') {
      child.props.onMouseEnter(e);
    }

    prefetch(router, href, as, {
      priority: true
    });
  }; // If child is an <a> tag and doesn't have a href attribute, or if the 'passHref' property is
  // defined, we specify the current 'href', so that repetition is not needed by the user


  if (props.passHref || child.type === 'a' && !('href' in child.props)) {
    childProps.href = (0, _router.addBasePath)((0, _router.addLocale)(as, typeof locale !== 'undefined' ? locale : router && router.locale, router && router.defaultLocale));
  }

  return /*#__PURE__*/_react.default.cloneElement(child, childProps);
}

var _default = Link;
exports.default = _default;

/***/ }),

/***/ "dZ6Y":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = mitt;
/*
MIT License
Copyright (c) Jason Miller (https://jasonformat.com/)
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
// This file is based on https://github.com/developit/mitt/blob/v1.1.3/src/index.js
// It's been edited for the needs of this script
// See the LICENSE at the top of the file

function mitt() {
  const all = Object.create(null);
  return {
    on(type, handler) {
      ;
      (all[type] || (all[type] = [])).push(handler);
    },

    off(type, handler) {
      if (all[type]) {
        all[type].splice(all[type].indexOf(handler) >>> 0, 1);
      }
    },

    emit(type, ...evts) {
      // eslint-disable-next-line array-callback-return
      ;
      (all[type] || []).slice().map(handler => {
        handler(...evts);
      });
    }

  };
}

/***/ }),

/***/ "elyg":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.addLocale = addLocale;
exports.delLocale = delLocale;
exports.hasBasePath = hasBasePath;
exports.addBasePath = addBasePath;
exports.delBasePath = delBasePath;
exports.isLocalURL = isLocalURL;
exports.interpolateAs = interpolateAs;
exports.resolveHref = resolveHref;
exports.default = void 0;

var _normalizeTrailingSlash = __webpack_require__("X24+");

var _routeLoader = __webpack_require__("Nh2W");

var _denormalizePagePath = __webpack_require__("wkBG");

var _mitt = _interopRequireDefault(__webpack_require__("dZ6Y"));

var _utils = __webpack_require__("g/15");

var _escapePathDelimiters = _interopRequireDefault(__webpack_require__("fcRV"));

var _isDynamic = __webpack_require__("/jkW");

var _parseRelativeUrl = __webpack_require__("hS4m");

var _querystring = __webpack_require__("3WeD");

var _resolveRewrites = _interopRequireDefault(__webpack_require__("S3md"));

var _routeMatcher = __webpack_require__("gguc");

var _routeRegex = __webpack_require__("YTqd");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}
/* global __NEXT_DATA__ */
// tslint:disable:no-console


const basePath =  false || '';

function buildCancellationError() {
  return Object.assign(new Error('Route Cancelled'), {
    cancelled: true
  });
}

function addPathPrefix(path, prefix) {
  return prefix && path.startsWith('/') ? path === '/' ? (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(prefix) : `${prefix}${path}` : path;
}

function addLocale(path, locale, defaultLocale) {
  if (false) {}

  return path;
}

function delLocale(path, locale) {
  if (false) {}

  return path;
}

function hasBasePath(path) {
  return path === basePath || path.startsWith(basePath + '/');
}

function addBasePath(path) {
  // we only add the basepath on relative urls
  return addPathPrefix(path, basePath);
}

function delBasePath(path) {
  return path.slice(basePath.length) || '/';
}
/**
* Detects whether a given url is routable by the Next.js router (browser only).
*/


function isLocalURL(url) {
  if (url.startsWith('/')) return true;

  try {
    // absolute urls can be local if they are on the same origin
    const locationOrigin = (0, _utils.getLocationOrigin)();
    const resolved = new URL(url, locationOrigin);
    return resolved.origin === locationOrigin && hasBasePath(resolved.pathname);
  } catch (_) {
    return false;
  }
}

function interpolateAs(route, asPathname, query) {
  let interpolatedRoute = '';
  const dynamicRegex = (0, _routeRegex.getRouteRegex)(route);
  const dynamicGroups = dynamicRegex.groups;
  const dynamicMatches = // Try to match the dynamic route against the asPath
  (asPathname !== route ? (0, _routeMatcher.getRouteMatcher)(dynamicRegex)(asPathname) : '') || // Fall back to reading the values from the href
  // TODO: should this take priority; also need to change in the router.
  query;
  interpolatedRoute = route;
  const params = Object.keys(dynamicGroups);

  if (!params.every(param => {
    let value = dynamicMatches[param] || '';
    const {
      repeat,
      optional
    } = dynamicGroups[param]; // support single-level catch-all
    // TODO: more robust handling for user-error (passing `/`)

    let replaced = `[${repeat ? '...' : ''}${param}]`;

    if (optional) {
      replaced = `${!value ? '/' : ''}[${replaced}]`;
    }

    if (repeat && !Array.isArray(value)) value = [value];
    return (optional || param in dynamicMatches) && ( // Interpolate group into data URL if present
    interpolatedRoute = interpolatedRoute.replace(replaced, repeat ? value.map(_escapePathDelimiters.default).join('/') : (0, _escapePathDelimiters.default)(value)) || '/');
  })) {
    interpolatedRoute = ''; // did not satisfy all requirements
    // n.b. We ignore this error because we handle warning for this case in
    // development in the `<Link>` component directly.
  }

  return {
    params,
    result: interpolatedRoute
  };
}

function omitParmsFromQuery(query, params) {
  const filteredQuery = {};
  Object.keys(query).forEach(key => {
    if (!params.includes(key)) {
      filteredQuery[key] = query[key];
    }
  });
  return filteredQuery;
}
/**
* Resolves a given hyperlink with a certain router state (basePath not included).
* Preserves absolute urls.
*/


function resolveHref(currentPath, href, resolveAs) {
  // we use a dummy base url for relative urls
  const base = new URL(currentPath, 'http://n');
  const urlAsString = typeof href === 'string' ? href : (0, _utils.formatWithValidation)(href); // Return because it cannot be routed by the Next.js router

  if (!isLocalURL(urlAsString)) {
    return resolveAs ? [urlAsString] : urlAsString;
  }

  try {
    const finalUrl = new URL(urlAsString, base);
    finalUrl.pathname = (0, _normalizeTrailingSlash.normalizePathTrailingSlash)(finalUrl.pathname);
    let interpolatedAs = '';

    if ((0, _isDynamic.isDynamicRoute)(finalUrl.pathname) && finalUrl.searchParams && resolveAs) {
      const query = (0, _querystring.searchParamsToUrlQuery)(finalUrl.searchParams);
      const {
        result,
        params
      } = interpolateAs(finalUrl.pathname, finalUrl.pathname, query);

      if (result) {
        interpolatedAs = (0, _utils.formatWithValidation)({
          pathname: result,
          hash: finalUrl.hash,
          query: omitParmsFromQuery(query, params)
        });
      }
    } // if the origin didn't change, it means we received a relative href


    const resolvedHref = finalUrl.origin === base.origin ? finalUrl.href.slice(finalUrl.origin.length) : finalUrl.href;
    return resolveAs ? [resolvedHref, interpolatedAs || resolvedHref] : resolvedHref;
  } catch (_) {
    return resolveAs ? [urlAsString] : urlAsString;
  }
}

function prepareUrlAs(router, url, as) {
  // If url and as provided as an object representation,
  // we'll format them into the string version here.
  return {
    url: addBasePath(resolveHref(router.pathname, url)),
    as: as ? addBasePath(resolveHref(router.pathname, as)) : as
  };
}

const manualScrollRestoration =  false && false;
const SSG_DATA_NOT_FOUND_ERROR = 'SSG Data NOT_FOUND';

function fetchRetry(url, attempts) {
  return fetch(url, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: 'same-origin'
  }).then(res => {
    if (!res.ok) {
      if (attempts > 1 && res.status >= 500) {
        return fetchRetry(url, attempts - 1);
      }

      if (res.status === 404) {
        // TODO: handle reloading in development from fallback returning 200
        // to on-demand-entry-handler causing it to reload periodically
        throw new Error(SSG_DATA_NOT_FOUND_ERROR);
      }

      throw new Error(`Failed to load static props`);
    }

    return res.json();
  });
}

function fetchNextData(dataHref, isServerRender) {
  return fetchRetry(dataHref, isServerRender ? 3 : 1).catch(err => {
    // We should only trigger a server-side transition if this was caused
    // on a client-side transition. Otherwise, we'd get into an infinite
    // loop.
    if (!isServerRender) {
      (0, _routeLoader.markAssetError)(err);
    }

    throw err;
  });
}

class Router {
  /**
  * Map of all components loaded in `Router`
  */
  // Static Data Cache
  constructor(_pathname, _query, _as, {
    initialProps,
    pageLoader,
    App,
    wrapApp,
    Component,
    err,
    subscription,
    isFallback,
    locale,
    locales,
    defaultLocale
  }) {
    this.route = void 0;
    this.pathname = void 0;
    this.query = void 0;
    this.asPath = void 0;
    this.basePath = void 0;
    this.components = void 0;
    this.sdc = {};
    this.sub = void 0;
    this.clc = void 0;
    this.pageLoader = void 0;
    this._bps = void 0;
    this.events = void 0;
    this._wrapApp = void 0;
    this.isSsr = void 0;
    this.isFallback = void 0;
    this._inFlightRoute = void 0;
    this._shallow = void 0;
    this.locale = void 0;
    this.locales = void 0;
    this.defaultLocale = void 0;

    this.onPopState = e => {
      const state = e.state;

      if (!state) {
        // We get state as undefined for two reasons.
        //  1. With older safari (< 8) and older chrome (< 34)
        //  2. When the URL changed with #
        //
        // In the both cases, we don't need to proceed and change the route.
        // (as it's already changed)
        // But we can simply replace the state with the new changes.
        // Actually, for (1) we don't need to nothing. But it's hard to detect that event.
        // So, doing the following for (1) does no harm.
        const {
          pathname,
          query
        } = this;
        this.changeState('replaceState', (0, _utils.formatWithValidation)({
          pathname: addBasePath(pathname),
          query
        }), (0, _utils.getURL)());
        return;
      }

      if (!state.__N) {
        return;
      }

      const {
        url,
        as,
        options
      } = state;
      const {
        pathname
      } = (0, _parseRelativeUrl.parseRelativeUrl)(url); // Make sure we don't re-render on initial load,
      // can be caused by navigating back from an external site

      if (this.isSsr && as === this.asPath && pathname === this.pathname) {
        return;
      } // If the downstream application returns falsy, return.
      // They will then be responsible for handling the event.


      if (this._bps && !this._bps(state)) {
        return;
      }

      this.change('replaceState', url, as, Object.assign({}, options, {
        shallow: options.shallow && this._shallow,
        locale: options.locale || this.defaultLocale
      }));
    }; // represents the current component key


    this.route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(_pathname); // set up the component cache (by route keys)

    this.components = {}; // We should not keep the cache, if there's an error
    // Otherwise, this cause issues when when going back and
    // come again to the errored page.

    if (_pathname !== '/_error') {
      this.components[this.route] = {
        Component,
        initial: true,
        props: initialProps,
        err,
        __N_SSG: initialProps && initialProps.__N_SSG,
        __N_SSP: initialProps && initialProps.__N_SSP
      };
    }

    this.components['/_app'] = {
      Component: App,
      styleSheets: [
        /* /_app does not need its stylesheets managed */
      ]
    }; // Backwards compat for Router.router.events
    // TODO: Should be remove the following major version as it was never documented

    this.events = Router.events;
    this.pageLoader = pageLoader;
    this.pathname = _pathname;
    this.query = _query; // if auto prerendered and dynamic route wait to update asPath
    // until after mount to prevent hydration mismatch

    this.asPath = // @ts-ignore this is temporarily global (attached to window)
    (0, _isDynamic.isDynamicRoute)(_pathname) && __NEXT_DATA__.autoExport ? _pathname : _as;
    this.basePath = basePath;
    this.sub = subscription;
    this.clc = null;
    this._wrapApp = wrapApp; // make sure to ignore extra popState in safari on navigating
    // back from external site

    this.isSsr = true;
    this.isFallback = isFallback;

    if (false) {}

    if (false) {}
  }

  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */


  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  push(url, as = url, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('pushState', url, as, options);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */


  replace(url, as = url, options = {}) {
    ;
    ({
      url,
      as
    } = prepareUrlAs(this, url, as));
    return this.change('replaceState', url, as, options);
  }

  async change(method, url, as, options) {
    if (!isLocalURL(url)) {
      window.location.href = url;
      return false;
    }

    let localeChange = options.locale !== this.locale;

    if (false) { var _this$locales; }

    if (!options._h) {
      this.isSsr = false;
    } // marking route changes as a navigation start entry


    if (_utils.ST) {
      performance.mark('routeChange');
    }

    if (this._inFlightRoute) {
      this.abortComponentLoad(this._inFlightRoute);
    }

    as = addBasePath(addLocale(hasBasePath(as) ? delBasePath(as) : as, options.locale, this.defaultLocale));
    const cleanedAs = delLocale(hasBasePath(as) ? delBasePath(as) : as, this.locale);
    this._inFlightRoute = as; // If the url change is only related to a hash change
    // We should not proceed. We should only change the state.
    // WARNING: `_h` is an internal option for handing Next.js client-side
    // hydration. Your app should _never_ use this property. It may change at
    // any time without notice.

    if (!options._h && this.onlyAHashChange(cleanedAs)) {
      this.asPath = cleanedAs;
      Router.events.emit('hashChangeStart', as); // TODO: do we need the resolved href when only a hash change?

      this.changeState(method, url, as, options);
      this.scrollToHash(cleanedAs);
      this.notify(this.components[this.route]);
      Router.events.emit('hashChangeComplete', as);
      return true;
    }

    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname,
      query
    } = parsed; // The build manifest needs to be loaded before auto-static dynamic pages
    // get their query parameters to allow ensuring they can be parsed properly
    // when rewritten to

    let pages, rewrites;

    try {
      pages = await this.pageLoader.getPageList();
      ({
        __rewrites: rewrites
      } = await (0, _routeLoader.getClientBuildManifest)());
    } catch (err) {
      // If we fail to resolve the page list or client-build manifest, we must
      // do a server-side transition:
      window.location.href = as;
      return false;
    }

    parsed = this._resolveHref(parsed, pages);

    if (parsed.pathname !== pathname) {
      pathname = parsed.pathname;
      url = (0, _utils.formatWithValidation)(parsed);
    } // url and as should always be prefixed with basePath by this
    // point by either next/link or router.push/replace so strip the
    // basePath from the pathname to match the pages dir 1-to-1


    pathname = pathname ? (0, _normalizeTrailingSlash.removePathTrailingSlash)(delBasePath(pathname)) : pathname; // If asked to change the current URL we should reload the current page
    // (not location.reload() but reload getInitialProps and other Next.js stuffs)
    // We also need to set the method = replaceState always
    // as this should not go into the history (That's how browsers work)
    // We should compare the new asPath to the current asPath, not the url

    if (!this.urlIsNew(cleanedAs) && !localeChange) {
      method = 'replaceState';
    }

    let route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
    const {
      shallow = false
    } = options; // we need to resolve the as value using rewrites for dynamic SSG
    // pages to allow building the data URL correctly

    let resolvedAs = as;

    if (false) {}

    resolvedAs = delLocale(delBasePath(resolvedAs), this.locale);

    if ((0, _isDynamic.isDynamicRoute)(route)) {
      const parsedAs = (0, _parseRelativeUrl.parseRelativeUrl)(resolvedAs);
      const asPathname = parsedAs.pathname;
      const routeRegex = (0, _routeRegex.getRouteRegex)(route);
      const routeMatch = (0, _routeMatcher.getRouteMatcher)(routeRegex)(asPathname);
      const shouldInterpolate = route === asPathname;
      const interpolatedAs = shouldInterpolate ? interpolateAs(route, asPathname, query) : {};

      if (!routeMatch || shouldInterpolate && !interpolatedAs.result) {
        const missingParams = Object.keys(routeRegex.groups).filter(param => !query[param]);

        if (missingParams.length > 0) {
          if (false) {}

          throw new Error((shouldInterpolate ? `The provided \`href\` (${url}) value is missing query values (${missingParams.join(', ')}) to be interpolated properly. ` : `The provided \`as\` value (${asPathname}) is incompatible with the \`href\` value (${route}). `) + `Read more: https://err.sh/vercel/next.js/${shouldInterpolate ? 'href-interpolation-failed' : 'incompatible-href-as'}`);
        }
      } else if (shouldInterpolate) {
        as = (0, _utils.formatWithValidation)(Object.assign({}, parsedAs, {
          pathname: interpolatedAs.result,
          query: omitParmsFromQuery(query, interpolatedAs.params)
        }));
      } else {
        // Merge params into `query`, overwriting any specified in search
        Object.assign(query, routeMatch);
      }
    }

    Router.events.emit('routeChangeStart', as);

    try {
      const routeInfo = await this.getRouteInfo(route, pathname, query, as, shallow);
      let {
        error,
        props,
        __N_SSG,
        __N_SSP
      } = routeInfo; // handle redirect on client-transition

      if ((__N_SSG || __N_SSP) && props && props.pageProps && props.pageProps.__N_REDIRECT) {
        const destination = props.pageProps.__N_REDIRECT; // check if destination is internal (resolves to a page) and attempt
        // client-navigation if it is falling back to hard navigation if
        // it's not

        if (destination.startsWith('/')) {
          const parsedHref = (0, _parseRelativeUrl.parseRelativeUrl)(destination);

          this._resolveHref(parsedHref, pages, false);

          if (pages.includes(parsedHref.pathname)) {
            const {
              url: newUrl,
              as: newAs
            } = prepareUrlAs(this, destination, destination);
            return this.change(method, newUrl, newAs, options);
          }
        }

        window.location.href = destination;
        return new Promise(() => {});
      }

      Router.events.emit('beforeHistoryChange', as);
      this.changeState(method, url, as, options);

      if (false) {}

      await this.set(route, pathname, query, cleanedAs, routeInfo).catch(e => {
        if (e.cancelled) error = error || e;else throw e;
      });

      if (error) {
        Router.events.emit('routeChangeError', error, cleanedAs);
        throw error;
      }

      if (false) {}

      if (false) {}

      Router.events.emit('routeChangeComplete', as);
      return true;
    } catch (err) {
      if (err.cancelled) {
        return false;
      }

      throw err;
    }
  }

  changeState(method, url, as, options = {}) {
    if (false) {}

    if (method !== 'pushState' || (0, _utils.getURL)() !== as) {
      this._shallow = options.shallow;
      window.history[method]({
        url,
        as,
        options,
        __N: true
      }, // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      '', as);
    }
  }

  async handleRouteInfoError(err, pathname, query, as, loadErrorFail) {
    if (err.cancelled) {
      // bubble up cancellation errors
      throw err;
    }

    if ((0, _routeLoader.isAssetError)(err) || loadErrorFail) {
      Router.events.emit('routeChangeError', err, as); // If we can't load the page it could be one of following reasons
      //  1. Page doesn't exists
      //  2. Page does exist in a different zone
      //  3. Internal error while loading the page
      // So, doing a hard reload is the proper way to deal with this.

      window.location.href = as; // Changing the URL doesn't block executing the current code path.
      // So let's throw a cancellation error stop the routing logic.

      throw buildCancellationError();
    }

    try {
      let Component;
      let styleSheets;
      let props;
      const ssg404 = err.message === SSG_DATA_NOT_FOUND_ERROR;

      if (ssg404) {
        try {
          let mod;
          ({
            page: Component,
            styleSheets,
            mod
          } = await this.fetchComponent('/404')); // TODO: should we tolerate these props missing and still render the
          // page instead of falling back to _error?

          if (mod && mod.__N_SSG) {
            props = await this._getStaticData(this.pageLoader.getDataHref('/404', '/404', true, this.locale));
          }
        } catch (_err) {// non-fatal fallback to _error
        }
      }

      if (typeof Component === 'undefined' || typeof styleSheets === 'undefined') {
        ;
        ({
          page: Component,
          styleSheets
        } = await this.fetchComponent('/_error'));
      }

      const routeInfo = {
        props,
        Component,
        styleSheets,
        err: ssg404 ? undefined : err,
        error: ssg404 ? undefined : err
      };

      if (!routeInfo.props) {
        try {
          routeInfo.props = await this.getInitialProps(Component, {
            err,
            pathname,
            query
          });
        } catch (gipErr) {
          console.error('Error in error page `getInitialProps`: ', gipErr);
          routeInfo.props = {};
        }
      }

      return routeInfo;
    } catch (routeInfoErr) {
      return this.handleRouteInfoError(routeInfoErr, pathname, query, as, true);
    }
  }

  async getRouteInfo(route, pathname, query, as, shallow = false) {
    try {
      const existingRouteInfo = this.components[route];

      if (shallow && existingRouteInfo && this.route === route) {
        return existingRouteInfo;
      }

      const cachedRouteInfo = existingRouteInfo && 'initial' in existingRouteInfo ? undefined : existingRouteInfo;
      const routeInfo = cachedRouteInfo ? cachedRouteInfo : await this.fetchComponent(route).then(res => ({
        Component: res.page,
        styleSheets: res.styleSheets,
        __N_SSG: res.mod.__N_SSG,
        __N_SSP: res.mod.__N_SSP
      }));
      const {
        Component,
        __N_SSG,
        __N_SSP
      } = routeInfo;

      if (false) {}

      let dataHref;

      if (__N_SSG || __N_SSP) {
        dataHref = this.pageLoader.getDataHref((0, _utils.formatWithValidation)({
          pathname,
          query
        }), delBasePath(as), __N_SSG, this.locale);
      }

      const props = await this._getData(() => __N_SSG ? this._getStaticData(dataHref) : __N_SSP ? this._getServerData(dataHref) : this.getInitialProps(Component, // we provide AppTree later so this needs to be `any`
      {
        pathname,
        query,
        asPath: as
      }));
      routeInfo.props = props;
      this.components[route] = routeInfo;
      return routeInfo;
    } catch (err) {
      return this.handleRouteInfoError(err, pathname, query, as);
    }
  }

  set(route, pathname, query, as, data) {
    this.isFallback = false;
    this.route = route;
    this.pathname = pathname;
    this.query = query;
    this.asPath = as;
    return this.notify(data);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */


  beforePopState(cb) {
    this._bps = cb;
  }

  onlyAHashChange(as) {
    if (!this.asPath) return false;
    const [oldUrlNoHash, oldHash] = this.asPath.split('#');
    const [newUrlNoHash, newHash] = as.split('#'); // Makes sure we scroll to the provided hash if the url/hash are the same

    if (newHash && oldUrlNoHash === newUrlNoHash && oldHash === newHash) {
      return true;
    } // If the urls are change, there's more than a hash change


    if (oldUrlNoHash !== newUrlNoHash) {
      return false;
    } // If the hash has changed, then it's a hash only change.
    // This check is necessary to handle both the enter and
    // leave hash === '' cases. The identity case falls through
    // and is treated as a next reload.


    return oldHash !== newHash;
  }

  scrollToHash(as) {
    const [, hash] = as.split('#'); // Scroll to top if the hash is just `#` with no value

    if (hash === '') {
      window.scrollTo(0, 0);
      return;
    } // First we check if the element by id is found


    const idEl = document.getElementById(hash);

    if (idEl) {
      idEl.scrollIntoView();
      return;
    } // If there's no element with the id, we check the `name` property
    // To mirror browsers


    const nameEl = document.getElementsByName(hash)[0];

    if (nameEl) {
      nameEl.scrollIntoView();
    }
  }

  urlIsNew(asPath) {
    return this.asPath !== asPath;
  }

  _resolveHref(parsedHref, pages, applyBasePath = true) {
    const {
      pathname
    } = parsedHref;
    const cleanPathname = (0, _normalizeTrailingSlash.removePathTrailingSlash)((0, _denormalizePagePath.denormalizePagePath)(applyBasePath ? delBasePath(pathname) : pathname));

    if (cleanPathname === '/404' || cleanPathname === '/_error') {
      return parsedHref;
    } // handle resolving href for dynamic routes


    if (!pages.includes(cleanPathname)) {
      // eslint-disable-next-line array-callback-return
      pages.some(page => {
        if ((0, _isDynamic.isDynamicRoute)(page) && (0, _routeRegex.getRouteRegex)(page).re.test(cleanPathname)) {
          parsedHref.pathname = applyBasePath ? addBasePath(page) : page;
          return true;
        }
      });
    }

    return parsedHref;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */


  async prefetch(url, asPath = url, options = {}) {
    let parsed = (0, _parseRelativeUrl.parseRelativeUrl)(url);
    let {
      pathname
    } = parsed;

    if (false) {}

    const pages = await this.pageLoader.getPageList();
    parsed = this._resolveHref(parsed, pages, false);

    if (parsed.pathname !== pathname) {
      pathname = parsed.pathname;
      url = (0, _utils.formatWithValidation)(parsed);
    } // Prefetch is not supported in development mode because it would trigger on-demand-entries


    if (false) {}

    const route = (0, _normalizeTrailingSlash.removePathTrailingSlash)(pathname);
    await Promise.all([this.pageLoader._isSsg(url).then(isSsg => {
      return isSsg ? this._getStaticData(this.pageLoader.getDataHref(url, asPath, true, typeof options.locale !== 'undefined' ? options.locale : this.locale)) : false;
    }), this.pageLoader[options.priority ? 'loadPage' : 'prefetch'](route)]);
  }

  async fetchComponent(route) {
    let cancelled = false;

    const cancel = this.clc = () => {
      cancelled = true;
    };

    const componentResult = await this.pageLoader.loadPage(route);

    if (cancelled) {
      const error = new Error(`Abort fetching component for route: "${route}"`);
      error.cancelled = true;
      throw error;
    }

    if (cancel === this.clc) {
      this.clc = null;
    }

    return componentResult;
  }

  _getData(fn) {
    let cancelled = false;

    const cancel = () => {
      cancelled = true;
    };

    this.clc = cancel;
    return fn().then(data => {
      if (cancel === this.clc) {
        this.clc = null;
      }

      if (cancelled) {
        const err = new Error('Loading initial props cancelled');
        err.cancelled = true;
        throw err;
      }

      return data;
    });
  }

  _getStaticData(dataHref) {
    const {
      href: cacheKey
    } = new URL(dataHref, window.location.href);

    if ( true && this.sdc[cacheKey]) {
      return Promise.resolve(this.sdc[cacheKey]);
    }

    return fetchNextData(dataHref, this.isSsr).then(data => {
      this.sdc[cacheKey] = data;
      return data;
    });
  }

  _getServerData(dataHref) {
    return fetchNextData(dataHref, this.isSsr);
  }

  getInitialProps(Component, ctx) {
    const {
      Component: App
    } = this.components['/_app'];

    const AppTree = this._wrapApp(App);

    ctx.AppTree = AppTree;
    return (0, _utils.loadGetInitialProps)(App, {
      AppTree,
      Component,
      router: this,
      ctx
    });
  }

  abortComponentLoad(as) {
    if (this.clc) {
      Router.events.emit('routeChangeError', buildCancellationError(), as);
      this.clc();
      this.clc = null;
    }
  }

  notify(data) {
    return this.sub(data, this.components['/_app'].Component);
  }

}

exports.default = Router;
Router.events = (0, _mitt.default)();

/***/ }),

/***/ "fcRV":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.default = escapePathDelimiters; // escape delimiters used by path-to-regexp

function escapePathDelimiters(segment) {
  return segment.replace(/[/#?]/g, char => encodeURIComponent(char));
}

/***/ }),

/***/ "g/15":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.execOnce = execOnce;
exports.getLocationOrigin = getLocationOrigin;
exports.getURL = getURL;
exports.getDisplayName = getDisplayName;
exports.isResSent = isResSent;
exports.loadGetInitialProps = loadGetInitialProps;
exports.formatWithValidation = formatWithValidation;
exports.ST = exports.SP = exports.urlObjectKeys = void 0;

var _formatUrl = __webpack_require__("6D7l");
/**
* Utils
*/


function execOnce(fn) {
  let used = false;
  let result;
  return (...args) => {
    if (!used) {
      used = true;
      result = fn(...args);
    }

    return result;
  };
}

function getLocationOrigin() {
  const {
    protocol,
    hostname,
    port
  } = window.location;
  return `${protocol}//${hostname}${port ? ':' + port : ''}`;
}

function getURL() {
  const {
    href
  } = window.location;
  const origin = getLocationOrigin();
  return href.substring(origin.length);
}

function getDisplayName(Component) {
  return typeof Component === 'string' ? Component : Component.displayName || Component.name || 'Unknown';
}

function isResSent(res) {
  return res.finished || res.headersSent;
}

async function loadGetInitialProps(App, ctx) {
  if (false) { var _App$prototype; } // when called from _app `ctx` is nested in `ctx`


  const res = ctx.res || ctx.ctx && ctx.ctx.res;

  if (!App.getInitialProps) {
    if (ctx.ctx && ctx.Component) {
      // @ts-ignore pageProps default
      return {
        pageProps: await loadGetInitialProps(ctx.Component, ctx.ctx)
      };
    }

    return {};
  }

  const props = await App.getInitialProps(ctx);

  if (res && isResSent(res)) {
    return props;
  }

  if (!props) {
    const message = `"${getDisplayName(App)}.getInitialProps()" should resolve to an object. But found "${props}" instead.`;
    throw new Error(message);
  }

  if (false) {}

  return props;
}

const urlObjectKeys = ['auth', 'hash', 'host', 'hostname', 'href', 'path', 'pathname', 'port', 'protocol', 'query', 'search', 'slashes'];
exports.urlObjectKeys = urlObjectKeys;

function formatWithValidation(url) {
  if (false) {}

  return (0, _formatUrl.formatUrl)(url);
}

const SP = typeof performance !== 'undefined';
exports.SP = SP;
const ST = SP && typeof performance.mark === 'function' && typeof performance.measure === 'function';
exports.ST = ST;

/***/ }),

/***/ "gguc":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.getRouteMatcher = getRouteMatcher;

function getRouteMatcher(routeRegex) {
  const {
    re,
    groups
  } = routeRegex;
  return pathname => {
    const routeMatch = re.exec(pathname);

    if (!routeMatch) {
      return false;
    }

    const decode = param => {
      try {
        return decodeURIComponent(param);
      } catch (_) {
        const err = new Error('failed to decode param');
        err.code = 'DECODE_FAILED';
        throw err;
      }
    };

    const params = {};
    Object.keys(groups).forEach(slugName => {
      const g = groups[slugName];
      const m = routeMatch[g.pos];

      if (m !== undefined) {
        params[slugName] = ~m.indexOf('/') ? m.split('/').map(entry => decode(entry)) : g.repeat ? [decode(m)] : decode(m);
      }
    });
    return params;
  };
}

/***/ }),

/***/ "hS4m":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.parseRelativeUrl = parseRelativeUrl;

var _utils = __webpack_require__("g/15");

var _querystring = __webpack_require__("3WeD");
/**
* Parses path-relative urls (e.g. `/hello/world?foo=bar`). If url isn't path-relative
* (e.g. `./hello`) then at least base must be.
* Absolute urls are rejected with one exception, in the browser, absolute urls that are on
* the current origin will be parsed as relative
*/


function parseRelativeUrl(url, base) {
  const globalBase = new URL(true ? 'http://n' : undefined);
  const resolvedBase = base ? new URL(base, globalBase) : globalBase;
  const {
    pathname,
    searchParams,
    search,
    hash,
    href,
    origin
  } = new URL(url, resolvedBase);

  if (origin !== globalBase.origin) {
    throw new Error('invariant: invalid relative URL');
  }

  return {
    pathname,
    query: (0, _querystring.searchParamsToUrlQuery)(searchParams),
    search,
    hash,
    href: href.slice(globalBase.origin.length)
  };
}

/***/ }),

/***/ "hXCp":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"loaderContainer": "loader_loaderContainer__2Ae9P"
};


/***/ }),

/***/ "iYUx":
/***/ (function(module, exports) {

module.exports = require("react-lottie");

/***/ }),

/***/ "k0r5":
/***/ (function(module) {

module.exports = JSON.parse("{\"v\":\"5.5.0\",\"fr\":25,\"ip\":0,\"op\":100,\"w\":149,\"h\":149,\"nm\":\"Comp 1\",\"ddd\":0,\"assets\":[],\"layers\":[{\"ddd\":0,\"ind\":1,\"ty\":4,\"nm\":\"Capa 2/ coche Outlines 2\",\"parent\":4,\"td\":1,\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":0,\"k\":[58,45.75,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[58,45.5,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[-0.439,1.807],[-1.611,2.832],[-2.637,0.342],[-15.088,0],[-3.662,-0.635],[-1.367,-2.294],[-1.269,-5.371],[1.855,0.146],[17.675,0],[8.106,-0.489]],\"o\":[[1.123,-5.371],[1.318,-2.294],[3.711,-0.537],[15.136,0],[2.637,0.391],[1.661,2.784],[0.44,1.807],[-8.106,-0.489],[-17.627,0],[-1.904,0.146]],\"v\":[[-37.622,8.57],[-32.495,-6.617],[-27.124,-10.23],[-0.025,-11.059],[27.075,-10.23],[32.446,-6.617],[37.622,8.57],[35.424,10.913],[-0.025,9.887],[-35.426,10.913]],\"c\":true},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"fl\",\"c\":{\"a\":0,\"k\":[1,1,1,1],\"ix\":4},\"o\":{\"a\":0,\"k\":100,\"ix\":5},\"r\":1,\"bm\":0,\"nm\":\"Fill 1\",\"mn\":\"ADBE Vector Graphic - Fill\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[57.788,19.36],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 1\",\"np\":2,\"cix\":2,\"bm\":0,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":0,\"op\":100,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":2,\"ty\":4,\"nm\":\"Capa 4/ coche Outlines\",\"parent\":4,\"tt\":1,\"sr\":1,\"ks\":{\"o\":{\"a\":1,\"k\":[{\"i\":{\"x\":[0.833],\"y\":[0.833]},\"o\":{\"x\":[0.167],\"y\":[0.167]},\"t\":0,\"s\":[100]},{\"i\":{\"x\":[0.833],\"y\":[0.833]},\"o\":{\"x\":[0.167],\"y\":[0.167]},\"t\":25,\"s\":[100]},{\"i\":{\"x\":[0.833],\"y\":[0.833]},\"o\":{\"x\":[0.167],\"y\":[0.167]},\"t\":28,\"s\":[0]},{\"i\":{\"x\":[0.833],\"y\":[0.833]},\"o\":{\"x\":[0.167],\"y\":[0.167]},\"t\":47,\"s\":[0]},{\"t\":50,\"s\":[100]}],\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":1,\"k\":[{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":0,\"s\":[58,70.375,0],\"to\":[0,-14.562,0],\"ti\":[0,14.562,0]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":25,\"s\":[58,-17,0],\"to\":[0,0,0],\"ti\":[0,0,0]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":28,\"s\":[58,-17,0],\"to\":[0,12.583,0],\"ti\":[0,1.583,0]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":47,\"s\":[58,58.5,0],\"to\":[0,-1.583,0],\"ti\":[0,14.167,0]},{\"t\":75,\"s\":[58,-26.5,0]}],\"ix\":2},\"a\":{\"a\":0,\"k\":[58,45.5,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[-3,3],[3,-3]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.9058823529411765,0.29411764705882354,0.23137254901960785,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":5,\"ix\":5},\"lc\":2,\"lj\":1,\"ml\":4,\"bm\":0,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[78.2,15.2],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 1\",\"np\":2,\"cix\":2,\"bm\":0,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[-9.6,9.2],[9.6,-9.2]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.9058823529411765,0.29411764705882354,0.23137254901960785,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":5,\"ix\":5},\"lc\":2,\"lj\":1,\"ml\":4,\"bm\":0,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[26.6,39.6],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 2\",\"np\":2,\"cix\":2,\"bm\":0,\"ix\":2,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[-9.6,9.2],[9.6,-9.2]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.9058823529411765,0.29411764705882354,0.23137254901960785,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":5,\"ix\":5},\"lc\":2,\"lj\":1,\"ml\":4,\"bm\":0,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[57.8,34.8],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 3\",\"np\":2,\"cix\":2,\"bm\":0,\"ix\":3,\"mn\":\"ADBE Vector Group\",\"hd\":false},{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,0]],\"o\":[[0,0],[0,0]],\"v\":[[-9.6,9.2],[9.6,-9.2]],\"c\":false},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"st\",\"c\":{\"a\":0,\"k\":[0.9058823529411765,0.29411764705882354,0.23137254901960785,1],\"ix\":3},\"o\":{\"a\":0,\"k\":100,\"ix\":4},\"w\":{\"a\":0,\"k\":5,\"ix\":5},\"lc\":2,\"lj\":1,\"ml\":4,\"bm\":0,\"nm\":\"Stroke 1\",\"mn\":\"ADBE Vector Graphic - Stroke\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[53.8,13.2],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 4\",\"np\":2,\"cix\":2,\"bm\":0,\"ix\":4,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":0,\"op\":100,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":3,\"ty\":4,\"nm\":\"Capa 2/ coche Outlines\",\"parent\":4,\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":0,\"k\":[58,45.75,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[58,45.5,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[-0.439,1.807],[-1.611,2.832],[-2.637,0.342],[-15.088,0],[-3.662,-0.635],[-1.367,-2.294],[-1.269,-5.371],[1.855,0.146],[17.675,0],[8.106,-0.489]],\"o\":[[1.123,-5.371],[1.318,-2.294],[3.711,-0.537],[15.136,0],[2.637,0.391],[1.661,2.784],[0.44,1.807],[-8.106,-0.489],[-17.627,0],[-1.904,0.146]],\"v\":[[-37.622,8.57],[-32.495,-6.617],[-27.124,-10.23],[-0.025,-11.059],[27.075,-10.23],[32.446,-6.617],[37.622,8.57],[35.424,10.913],[-0.025,9.887],[-35.426,10.913]],\"c\":true},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"fl\",\"c\":{\"a\":0,\"k\":[1,1,1,1],\"ix\":4},\"o\":{\"a\":0,\"k\":100,\"ix\":5},\"r\":1,\"bm\":0,\"nm\":\"Fill 1\",\"mn\":\"ADBE Vector Graphic - Fill\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[57.788,19.36],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 1\",\"np\":2,\"cix\":2,\"bm\":0,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":0,\"op\":100,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":4,\"ty\":4,\"nm\":\"Capa 1/ coche Outlines\",\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":1,\"k\":[{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":0,\"s\":[74.5,72,0],\"to\":[0,0.667,0],\"ti\":[0,0,0]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":10,\"s\":[74.5,76,0],\"to\":[0,0,0],\"ti\":[0,0,0]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":20,\"s\":[74.5,72,0],\"to\":[0,0,0],\"ti\":[0,0,0]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":30,\"s\":[74.5,76,0],\"to\":[0,0,0],\"ti\":[0,0,0]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":40,\"s\":[74.5,72,0],\"to\":[0,0,0],\"ti\":[0,0,0]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":50,\"s\":[74.5,76,0],\"to\":[0,0,0],\"ti\":[0,0,0]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":60,\"s\":[74.5,72,0],\"to\":[0,0,0],\"ti\":[0,0,0]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":70,\"s\":[74.5,76,0],\"to\":[0,0,0],\"ti\":[0,0,0]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":80,\"s\":[74.5,72,0],\"to\":[0,0,0],\"ti\":[0,0,0]},{\"i\":{\"x\":0.833,\"y\":0.833},\"o\":{\"x\":0.167,\"y\":0.167},\"t\":90,\"s\":[74.5,76,0],\"to\":[0,0,0],\"ti\":[0,0.667,0]},{\"t\":99,\"s\":[74.5,72,0]}],\"ix\":2},\"a\":{\"a\":0,\"k\":[58,45.5,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[0,3.418],[-3.418,0],[0,0],[0,-3.467],[3.467,0]],\"o\":[[-3.418,0],[0,-3.467],[0,0],[3.467,0],[0,3.418],[0,0]],\"v\":[[-12.939,23.681],[-18.799,17.822],[-12.939,11.962],[12.939,11.962],[18.798,17.822],[12.939,23.681]],\"c\":true},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ind\":1,\"ty\":\"sh\",\"ix\":2,\"ks\":{\"a\":0,\"k\":{\"i\":[[4.59,0],[0,4.589],[-4.639,0],[0,-4.639]],\"o\":[[-4.639,0],[0,-4.639],[4.59,0],[0,4.589]],\"v\":[[35.645,25.927],[27.54,17.822],[35.645,9.716],[43.749,17.822]],\"c\":true},\"ix\":2},\"nm\":\"Path 2\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ind\":2,\"ty\":\"sh\",\"ix\":3,\"ks\":{\"a\":0,\"k\":{\"i\":[[4.59,0],[0,4.589],[-4.639,0],[0,-4.639]],\"o\":[[-4.639,0],[0,-4.639],[4.59,0],[0,4.589]],\"v\":[[-35.596,25.927],[-43.702,17.822],[-35.596,9.716],[-27.49,17.822]],\"c\":true},\"ix\":2},\"nm\":\"Path 3\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ind\":3,\"ty\":\"sh\",\"ix\":4,\"ks\":{\"a\":0,\"k\":{\"i\":[[-0.44,1.806],[-1.612,2.832],[-2.637,0.342],[-15.087,0],[-3.662,-0.635],[-1.367,-2.295],[-1.27,-5.371],[1.855,0.146],[17.676,0],[8.106,-0.489]],\"o\":[[1.123,-5.371],[1.318,-2.295],[3.711,-0.537],[15.137,0],[2.637,0.391],[1.66,2.783],[0.439,1.806],[-8.106,-0.489],[-17.626,0],[-1.904,0.146]],\"v\":[[-37.598,-10.645],[-32.471,-25.831],[-27.1,-29.444],[-0.001,-30.274],[27.1,-29.444],[32.471,-25.831],[37.646,-10.645],[35.45,-8.301],[-0.001,-9.327],[-35.4,-8.301]],\"c\":true},\"ix\":2},\"nm\":\"Path 4\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ind\":4,\"ty\":\"sh\",\"ix\":5,\"ks\":{\"a\":0,\"k\":{\"i\":[[0,0],[-12.548,0],[-10.84,0.683],[0,0],[0,0],[4.492,5.859],[0,0],[1.659,3.613],[6.494,0.879],[12.647,0],[3.271,-0.342],[2.588,-5.518],[1.806,-8.79],[0,0],[0,-8.203],[0,0]],\"o\":[[10.84,0.683],[12.549,0],[0,0],[0,0],[0,-8.203],[0,0],[-1.757,-8.79],[-2.637,-5.518],[-3.272,-0.391],[-12.597,0],[-6.494,0.781],[-1.709,3.613],[0,0],[-4.541,5.859],[0,0],[0,0]],\"v\":[[-39.062,37.402],[-0.001,38.574],[39.111,37.402],[57.764,37.425],[57.764,17.431],[51.611,-1.27],[47.46,-6.592],[40.771,-28.223],[26.611,-37.891],[-0.001,-38.575],[-26.562,-37.891],[-40.723,-28.223],[-47.46,-6.592],[-51.562,-1.27],[-57.764,17.431],[-57.764,37.425]],\"c\":true},\"ix\":2},\"nm\":\"Path 5\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"mm\",\"mm\":1,\"nm\":\"Merge Paths 1\",\"mn\":\"ADBE Vector Filter - Merge\",\"hd\":false},{\"ty\":\"fl\",\"c\":{\"a\":0,\"k\":[0.9058823529411765,0.29411764705882354,0.23137254901960785,1],\"ix\":4},\"o\":{\"a\":0,\"k\":100,\"ix\":5},\"r\":1,\"bm\":0,\"nm\":\"Fill 1\",\"mn\":\"ADBE Vector Graphic - Fill\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[57.764,38.574],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 1\",\"np\":9,\"cix\":2,\"bm\":0,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":0,\"op\":100,\"st\":0,\"bm\":0},{\"ddd\":0,\"ind\":5,\"ty\":4,\"nm\":\"Capa 3/ coche Outlines\",\"sr\":1,\"ks\":{\"o\":{\"a\":0,\"k\":100,\"ix\":11},\"r\":{\"a\":0,\"k\":0,\"ix\":10},\"p\":{\"a\":0,\"k\":[74.5,75,0],\"ix\":2},\"a\":{\"a\":0,\"k\":[58,45.5,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100,100],\"ix\":6}},\"ao\":0,\"shapes\":[{\"ty\":\"gr\",\"it\":[{\"ind\":0,\"ty\":\"sh\",\"ix\":1,\"ks\":{\"a\":0,\"k\":{\"i\":[[-3.662,0],[0,0],[0,3.613],[0,0],[0,0],[0,0]],\"o\":[[0,0],[3.662,0],[0,0],[0,0],[0,0],[0,3.613]],\"v\":[[45.644,5.288],[51.357,5.288],[57.85,-1.108],[57.85,-5.288],[39.15,-5.288],[39.15,-1.108]],\"c\":true},\"ix\":2},\"nm\":\"Path 1\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ind\":1,\"ty\":\"sh\",\"ix\":2,\"ks\":{\"a\":0,\"k\":{\"i\":[[-3.662,0],[0,0],[0,3.613],[0,0],[0,0],[0,0]],\"o\":[[0,0],[3.662,0],[0,0],[0,0],[0,0],[0,3.613]],\"v\":[[-51.356,5.288],[-45.643,5.288],[-39.149,-1.108],[-39.149,-5.288],[-57.85,-5.288],[-57.85,-1.108]],\"c\":true},\"ix\":2},\"nm\":\"Path 2\",\"mn\":\"ADBE Vector Shape - Group\",\"hd\":false},{\"ty\":\"mm\",\"mm\":1,\"nm\":\"Merge Paths 1\",\"mn\":\"ADBE Vector Filter - Merge\",\"hd\":false},{\"ty\":\"fl\",\"c\":{\"a\":0,\"k\":[0.9058823529411765,0.29411764705882354,0.23137254901960785,1],\"ix\":4},\"o\":{\"a\":0,\"k\":100,\"ix\":5},\"r\":1,\"bm\":0,\"nm\":\"Fill 1\",\"mn\":\"ADBE Vector Graphic - Fill\",\"hd\":false},{\"ty\":\"tr\",\"p\":{\"a\":0,\"k\":[57.851,84.985],\"ix\":2},\"a\":{\"a\":0,\"k\":[0,0],\"ix\":1},\"s\":{\"a\":0,\"k\":[100,100],\"ix\":3},\"r\":{\"a\":0,\"k\":0,\"ix\":6},\"o\":{\"a\":0,\"k\":100,\"ix\":7},\"sk\":{\"a\":0,\"k\":0,\"ix\":4},\"sa\":{\"a\":0,\"k\":0,\"ix\":5},\"nm\":\"Transform\"}],\"nm\":\"Group 1\",\"np\":4,\"cix\":2,\"bm\":0,\"ix\":1,\"mn\":\"ADBE Vector Group\",\"hd\":false}],\"ip\":0,\"op\":100,\"st\":0,\"bm\":0}],\"markers\":[]}");

/***/ }),

/***/ "m/eG":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "x", function() { return /* reexport */ Layout; });
__webpack_require__.d(__webpack_exports__, "u", function() { return /* reexport */ Header; });
__webpack_require__.d(__webpack_exports__, "t", function() { return /* reexport */ Footer; });
__webpack_require__.d(__webpack_exports__, "A", function() { return /* reexport */ ProductCard; });
__webpack_require__.d(__webpack_exports__, "y", function() { return /* reexport */ Loader; });
__webpack_require__.d(__webpack_exports__, "q", function() { return /* reexport */ DetailsPage; });
__webpack_require__.d(__webpack_exports__, "w", function() { return /* reexport */ InnerHeader; });
__webpack_require__.d(__webpack_exports__, "n", function() { return /* reexport */ ContactForm; });
__webpack_require__.d(__webpack_exports__, "o", function() { return /* reexport */ ContactInfo; });
__webpack_require__.d(__webpack_exports__, "z", function() { return /* reexport */ NoData; });
__webpack_require__.d(__webpack_exports__, "s", function() { return /* reexport */ FilteredProducts; });
__webpack_require__.d(__webpack_exports__, "E", function() { return /* reexport */ Slider; });
__webpack_require__.d(__webpack_exports__, "v", function() { return /* reexport */ HomeAbout; });
__webpack_require__.d(__webpack_exports__, "j", function() { return /* reexport */ BrandSlider; });
__webpack_require__.d(__webpack_exports__, "e", function() { return /* reexport */ AdminLayout; });
__webpack_require__.d(__webpack_exports__, "d", function() { return /* reexport */ AdminHeader; });
__webpack_require__.d(__webpack_exports__, "D", function() { return /* reexport */ SideMenu; });
__webpack_require__.d(__webpack_exports__, "c", function() { return /* reexport */ AdminFooter; });
__webpack_require__.d(__webpack_exports__, "g", function() { return /* reexport */ AdminSectionHeader; });
__webpack_require__.d(__webpack_exports__, "h", function() { return /* reexport */ AdminTable; });
__webpack_require__.d(__webpack_exports__, "b", function() { return /* reexport */ AdmenFilterByDelete; });
__webpack_require__.d(__webpack_exports__, "f", function() { return /* reexport */ AdminModal; });
__webpack_require__.d(__webpack_exports__, "r", function() { return /* reexport */ EditBtn; });
__webpack_require__.d(__webpack_exports__, "p", function() { return /* reexport */ DeleteBtn; });
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ ActiveBtn; });
__webpack_require__.d(__webpack_exports__, "m", function() { return /* reexport */ ConfirmDelete; });
__webpack_require__.d(__webpack_exports__, "k", function() { return /* reexport */ CategoryForm; });
__webpack_require__.d(__webpack_exports__, "i", function() { return /* reexport */ BrandForm; });
__webpack_require__.d(__webpack_exports__, "G", function() { return /* reexport */ UploadImage; });
__webpack_require__.d(__webpack_exports__, "F", function() { return /* reexport */ SliderForm; });
__webpack_require__.d(__webpack_exports__, "C", function() { return /* reexport */ RolesForm; });
__webpack_require__.d(__webpack_exports__, "H", function() { return /* reexport */ UserForm; });
__webpack_require__.d(__webpack_exports__, "B", function() { return /* reexport */ ProductsForm; });
__webpack_require__.d(__webpack_exports__, "l", function() { return /* reexport */ ChangePasswordForm; });

// UNUSED EXPORTS: SpeedContact

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__("F5FC");

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__("xnum");
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// EXTERNAL MODULE: external "swr"
var external_swr_ = __webpack_require__("aYjl");
var external_swr_default = /*#__PURE__*/__webpack_require__.n(external_swr_);

// CONCATENATED MODULE: ./lib/swr-hooks.ts


function fetcher(url) {
  return window.fetch(url).then(res => res.json());
}

function useGet(url) {
  const {
    data,
    error
  } = external_swr_default()(`${url}`, fetcher);
  return {
    data: data,
    isLoading: !error && !data,
    isError: error
  };
}
function useEntry(id) {
  return external_swr_default()(`/api/get-entry?id=${id}`, fetcher);
}
// CONCATENATED MODULE: ./components/layout.tsx







const BrandsCategoriesContext = /*#__PURE__*/Object(external_react_["createContext"])([]);
function Layout({
  children
}) {
  var _brands$data, _brands$data2, _categories$data, _categories$data2;

  let lang;

  if (typeof Storage !== "undefined") {
    lang = localStorage.getItem('lang');
  }

  const brands = useGet('/api/brands/notDeleted');
  const categories = useGet('/api/categories/notDeleted');
  let BrandsArray = brands.data && brands.data.length > 0 && lang === 'ar' ? brands === null || brands === void 0 ? void 0 : (_brands$data = brands.data) === null || _brands$data === void 0 ? void 0 : _brands$data.map(d => ({
    id: d.id,
    name: d.title_ar
  })) : brands === null || brands === void 0 ? void 0 : (_brands$data2 = brands.data) === null || _brands$data2 === void 0 ? void 0 : _brands$data2.map(d => ({
    id: d.id,
    name: d.title
  }));
  let categoriesArray = categories.data && categories.data.length > 0 && lang === 'ar' ? categories === null || categories === void 0 ? void 0 : (_categories$data = categories.data) === null || _categories$data === void 0 ? void 0 : _categories$data.map(c => ({
    id: c.id,
    name: c.title_ar
  })) : categories === null || categories === void 0 ? void 0 : (_categories$data2 = categories.data) === null || _categories$data2 === void 0 ? void 0 : _categories$data2.map(c => ({
    id: c.id,
    name: c.title
  }));
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(jsx_runtime_["Fragment"], {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])(head_default.a, {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("title", {
        children: "International Export"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("link", {
        rel: "icon",
        href: "/fav.png"
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "w-100 bg-white position-fixed ",
      style: {
        zIndex: 999
      },
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(Header, {
        brands: BrandsArray,
        categories: categoriesArray
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      style: {
        minHeight: '80vh',
        paddingTop: '120px'
      },
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(BrandsCategoriesContext.Provider, {
        value: [categoriesArray, BrandsArray],
        children: children
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(Footer, {})]
  });
}
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__("YFqc");
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__("4Q3z");

// EXTERNAL MODULE: ./locals/localHook.tsx + 1 modules
var localHook = __webpack_require__("04F5");

// EXTERNAL MODULE: ./locals/langProvider.tsx
var langProvider = __webpack_require__("QMtg");

// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__("IZS3");

// EXTERNAL MODULE: external "@fortawesome/free-brands-svg-icons"
var free_brands_svg_icons_ = __webpack_require__("JVe5");

// EXTERNAL MODULE: external "@fortawesome/free-solid-svg-icons"
var free_solid_svg_icons_ = __webpack_require__("No/t");

// EXTERNAL MODULE: external "@fortawesome/react-fontawesome"
var react_fontawesome_ = __webpack_require__("uhWA");

// EXTERNAL MODULE: ./styles/speedContact.module.css
var speedContact_module = __webpack_require__("+8UP");
var speedContact_module_default = /*#__PURE__*/__webpack_require__.n(speedContact_module);

// CONCATENATED MODULE: ./components/speedContact.tsx







function SpeedContact() {
  const {
    data,
    isError,
    isLoading
  } = useGet('/api/contact/all');
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: speedContact_module_default.a.speedContact,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
      href: "#",
      className: `mx-2 ${speedContact_module_default.a.icon}`,
      target: "_blank",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
        icon: free_brands_svg_icons_["faInstagram"],
        color: "#FFF"
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
      href: "#",
      className: `mx-2 ${speedContact_module_default.a.icon}`,
      target: "_blank",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
        icon: free_brands_svg_icons_["faFacebook"],
        color: "#FFF"
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
      href: "#",
      className: `mx-2 ${speedContact_module_default.a.icon}`,
      target: "_blank",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
        icon: free_brands_svg_icons_["faYoutube"],
        color: "#FFF"
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
      href: "tel:010 - 950 - 950 - 11",
      className: `mx-2 ${speedContact_module_default.a.icon}`,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
        icon: free_solid_svg_icons_["faPhoneAlt"],
        color: "#FFF"
      })
    }), data && /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
      className: speedContact_module_default.a.phoneNo,
      href: `tel: ${data[0].phones.split(',')[0]}`,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
        children: data[0].phones.split(',')[0]
      })
    })]
  });
}
// CONCATENATED MODULE: ./components/header.tsx









function Header({
  brands,
  categories
}) {
  const router = Object(router_["useRouter"])(); // function to get the language translation 

  const {
    t
  } = Object(localHook["a" /* default */])(); // language context and function to change language

  const {
    0: locale,
    1: setLocale
  } = Object(external_react_["useContext"])(langProvider["a" /* LanguageContext */]);

  const changeLang = () => {
    let newLocal = t("ChangeLang").toLowerCase();
    setLocale(newLocal);
    localStorage.setItem('lang', newLocal);
    router.push(`${router.pathname}`);
  }; // get brand and category


  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: "container",
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_react_bootstrap_["Navbar"], {
      bg: "white",
      expand: "lg",
      className: "w-100 p-0",
      style: {
        maxHeight: '120px'
      },
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(SpeedContact, {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
        href: "/",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
            src: "/images/logo.png",
            width: 188,
            height: 133,
            alt: "International Export"
          })
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Navbar"].Toggle, {
        "aria-controls": "basic-navbar-nav"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Navbar"].Collapse, {
        id: "basic-navbar-nav",
        children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_react_bootstrap_["Nav"], {
          className: "ml-auto mt-md-5",
          dir: t("Dir"),
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
            href: "/",
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
              className: `nav-link ${router.pathname === '/' && 'active'}`,
              children: t("Home")
            })
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
            href: "/about",
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
              className: `nav-link ${router.pathname === '/about' && 'active'}`,
              children: t("About")
            })
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["NavDropdown"], {
            title: t("Products"),
            id: "products",
            children: categories === null || categories === void 0 ? void 0 : categories.map((category, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
              href: `/products?type=category&q=${category.name}`,
              children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
                className: "dropdown-item",
                children: category.name
              })
            }, i))
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["NavDropdown"], {
            title: t("Brands"),
            id: "Brands",
            children: brands === null || brands === void 0 ? void 0 : brands.map((brand, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
              href: `/products?type=brand&q=${brand.name}`,
              children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
                className: "dropdown-item",
                children: brand.name
              })
            }, i))
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
            href: "/contact",
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
              className: `nav-link ${router.pathname === '/contact' && 'active'}`,
              children: t("Contact")
            })
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Nav"].Link, {
            onClick: changeLang,
            children: t("ChangeLang")
          })]
        })
      })]
    })
  });
}
// CONCATENATED MODULE: ./components/footer.tsx


function Footer() {
  const {
    t
  } = Object(localHook["a" /* default */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("footer", {
    className: "row mx-0 bg-gradient justify-content-center",
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("small", {
      children: t("CopyRights")
    })
  });
}
// EXTERNAL MODULE: ./styles/productCard.module.css
var productCard_module = __webpack_require__("v/KB");
var productCard_module_default = /*#__PURE__*/__webpack_require__.n(productCard_module);

// EXTERNAL MODULE: external "react-reveal/Fade"
var Fade_ = __webpack_require__("IrP5");
var Fade_default = /*#__PURE__*/__webpack_require__.n(Fade_);

// CONCATENATED MODULE: ./components/productCard.tsx






function ProductCard({
  ProductItem
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(Fade_default.a, {
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
      href: `/products/${ProductItem.id}`,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
        type: "button",
        className: `card ${productCard_module_default.a.prCard} mb-5`,
        children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
          className: "card-body",
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
            src: ProductItem.image,
            alt: ProductItem.title,
            className: "w-100"
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
            children: ProductItem.title
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
            className: "text-justify",
            children: ProductItem.description.slice(0, 100)
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
            className: "row justify-content-center",
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
              href: `/products/${ProductItem.id}`,
              children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
                className: "btn btnPrimaryOutline mx-auto",
                children: t("ReadMore")
              })
            })
          })]
        })
      })
    })
  });
}
// EXTERNAL MODULE: ./styles/loader.module.css
var loader_module = __webpack_require__("hXCp");
var loader_module_default = /*#__PURE__*/__webpack_require__.n(loader_module);

// EXTERNAL MODULE: external "react-lottie"
var external_react_lottie_ = __webpack_require__("iYUx");
var external_react_lottie_default = /*#__PURE__*/__webpack_require__.n(external_react_lottie_);

// EXTERNAL MODULE: ./animationJson/carLoad.json
var carLoad = __webpack_require__("k0r5");

// CONCATENATED MODULE: ./components/loader.tsx




function Loader() {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: loader_module_default.a.loaderContainer,
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_lottie_default.a, {
      options: {
        loop: true,
        autoplay: true,
        animationData: carLoad
      },
      height: 200,
      width: 200
    })
  });
}
// CONCATENATED MODULE: ./components/details.tsx



function DetailsPage({
  details
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  const dir = t("Dir");
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: "container my-5",
    dir: dir,
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "row",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: "col-md-8 mx-auto",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h2", {
          className: `text-danger w-100 ${dir === 'rtl' && 'text-right'}`,
          children: details.title
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: "red-Divider w-50",
          dir: dir
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
          className: "text-justify my-4",
          dir: dir,
          children: details.details
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "col-md-4 text-center",
        children: details.image && /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
          src: details.image,
          width: 200,
          height: 'auto',
          alt: details.title
        })
      })]
    })
  });
}
// EXTERNAL MODULE: ./styles/innerHead.module.css
var innerHead_module = __webpack_require__("pdMe");
var innerHead_module_default = /*#__PURE__*/__webpack_require__.n(innerHead_module);

// CONCATENATED MODULE: ./components/innerpagesHeader.tsx


function InnerHeader({
  image
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: innerHead_module_default.a.innerHeader,
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
      src: image,
      className: "w-100"
    })
  });
}
// CONCATENATED MODULE: ./components/contactForm.tsx




function ContactForm() {
  const {
    t
  } = Object(localHook["a" /* default */])();
  const dir = t("Dir");
  const {
    0: cEmail,
    1: setCEmail
  } = Object(external_react_["useState"])("");
  const {
    0: cSubject,
    1: setCSubject
  } = Object(external_react_["useState"])("");
  const {
    0: cMessage,
    1: setCMessage
  } = Object(external_react_["useState"])("");
  const refEmail = Object(external_react_["useRef"])(null);
  const refSubject = Object(external_react_["useRef"])(null);
  const refMessage = Object(external_react_["useRef"])(null);

  const handleEmail = e => {
    refEmail.current.classList.remove('border');
    refEmail.current.classList.remove('border-danger');
    setCEmail(e.target.value);
  };

  const handleSubject = e => {
    refSubject.current.classList.remove('border');
    refSubject.current.classList.remove('border-danger');
    setCSubject(e.target.value);
  };

  const handleMessage = e => {
    refMessage.current.classList.remove('border');
    refMessage.current.classList.remove('border-danger');
    setCMessage(e.target.value);
  };

  const re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

  const sendMessage = async e => {
    e.preventDefault();

    if (!re.test(cEmail.toLowerCase())) {
      refEmail.current.classList.add('border');
      refEmail.current.classList.add('border-danger');
      refEmail.current.focus();
      return false;
    }

    if (cSubject.trim().length === 0) {
      refSubject.current.classList.add('border');
      refSubject.current.classList.add('border-danger');
      refSubject.current.focus();
      return false;
    }

    if (cMessage.trim().length === 0) {
      refMessage.current.classList.add('border');
      refMessage.current.classList.add('border-danger');
      refMessage.current.focus();
      return false;
    }

    const sent = await fetch('/api/sendEmail', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: cSubject,
        email: cEmail,
        message: cMessage
      })
    }).then(() => {
      setCEmail("");
      setCSubject("");
      setCMessage("");
    });
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    dir: dir,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
      className: `text-danger w-100 ${dir === 'rtl' && 'text-right'}`,
      children: t("EmailUs")
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "red-Divider w-50"
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("form", {
      className: "my-4",
      onSubmit: sendMessage,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "form-group",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
          type: "email",
          ref: refEmail,
          className: "form-control",
          placeholder: t("Email"),
          value: cEmail,
          onChange: handleEmail
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "form-group",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
          type: "text",
          ref: refSubject,
          className: "form-control",
          placeholder: t("Subject"),
          value: cSubject,
          onChange: handleSubject
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "form-group",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("textarea", {
          className: "form-control",
          ref: refMessage,
          rows: 10,
          placeholder: t("Message"),
          value: cMessage,
          onChange: handleMessage
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "form-group",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
          className: "btn btnPrimary btn-block",
          children: t("Send")
        })
      })]
    })]
  });
}
// EXTERNAL MODULE: ./styles/contactInfo.module.css
var contactInfo_module = __webpack_require__("xlWK");
var contactInfo_module_default = /*#__PURE__*/__webpack_require__.n(contactInfo_module);

// CONCATENATED MODULE: ./components/contactInfo.tsx






function ContactInfo({
  contactInfo
}) {
  var _contactInfo$phones, _contactInfo$emails;

  const {
    t
  } = Object(localHook["a" /* default */])();
  const dir = t("Dir");
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    dir: dir,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h4", {
      className: `text-danger w-100 ${dir === 'rtl' && 'text-right'}`,
      children: t("ContactInfo")
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "red-Divider w-50"
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "my-3",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: "d-flex my-3",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: contactInfo_module_default.a.icon,
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
            icon: free_solid_svg_icons_["faMapMarkerAlt"],
            color: "#dc3545",
            style: {
              width: '15px'
            }
          })
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
          className: "m-0",
          children: contactInfo.address
        })]
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: "d-flex my-3",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: contactInfo_module_default.a.icon,
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
            icon: free_solid_svg_icons_["faPhoneAlt"],
            color: "#dc3545",
            style: {
              width: '15px'
            }
          })
        }), (_contactInfo$phones = contactInfo.phones) === null || _contactInfo$phones === void 0 ? void 0 : _contactInfo$phones.split(',').map((phone, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
          className: "m-0",
          children: phone
        }, i))]
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: "d-flex my-3",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: contactInfo_module_default.a.icon,
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
            icon: free_solid_svg_icons_["faEnvelope"],
            color: "#dc3545",
            style: {
              width: '15px'
            }
          })
        }), (_contactInfo$emails = contactInfo.emails) === null || _contactInfo$emails === void 0 ? void 0 : _contactInfo$emails.split(',').map((email, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
          className: "m-0",
          children: email
        }, i))]
      })]
    })]
  });
}
// EXTERNAL MODULE: ./animationJson/no.json
var no = __webpack_require__("4GzE");

// CONCATENATED MODULE: ./components/noData.tsx




function NoData({
  message
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    style: {
      marginTop: '-50px'
    },
    className: "w-100 d-flex flex-column justify-content-center align-items-center",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_lottie_default.a, {
      options: {
        loop: true,
        autoplay: true,
        animationData: no
      },
      height: 300,
      width: 300
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("h5", {
      style: {
        marginTop: '-80px'
      },
      className: "text-secondary",
      children: message
    })]
  });
}
// CONCATENATED MODULE: ./components/filterProducts.tsx





function FilteredProducts({
  filterProducts,
  type,
  q
}) {
  var _router$query, _router$query2, _router$query2$q, _router$query3, _router$query4, _router$query4$q;

  const {
    0: categoriesArray,
    1: BrandsArray
  } = Object(external_react_["useContext"])(BrandsCategoriesContext);
  const router = Object(router_["useRouter"])();
  const {
    0: filterTitle,
    1: setFilterTitle
  } = Object(external_react_["useState"])("");
  const {
    0: filterBrand,
    1: setFilterBrand
  } = Object(external_react_["useState"])(((_router$query = router.query) === null || _router$query === void 0 ? void 0 : _router$query.type) === 'brand' ? (_router$query2 = router.query) === null || _router$query2 === void 0 ? void 0 : (_router$query2$q = _router$query2.q) === null || _router$query2$q === void 0 ? void 0 : _router$query2$q.toString() : "");
  const {
    0: filterCategory,
    1: setFilterCategory
  } = Object(external_react_["useState"])(((_router$query3 = router.query) === null || _router$query3 === void 0 ? void 0 : _router$query3.type) === 'category' ? (_router$query4 = router.query) === null || _router$query4 === void 0 ? void 0 : (_router$query4$q = _router$query4.q) === null || _router$query4$q === void 0 ? void 0 : _router$query4$q.toString() : "");
  const titleFilter = Object(external_react_["useRef"])();
  const brandFilter = Object(external_react_["useRef"])();
  const categoryFilter = Object(external_react_["useRef"])();

  const changeTitle = () => {
    let title = titleFilter.current.value;
    setFilterTitle(title);
    filterProducts(title, filterBrand, filterCategory);
  };

  const changeBrand = () => {
    let brand = brandFilter.current.value;
    setFilterBrand(brand);
    filterProducts(filterTitle, brand, filterCategory);
  };

  const changeCategory = () => {
    let category = categoryFilter.current.value;
    setFilterCategory(category);
    filterProducts(filterTitle, filterBrand, category);
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "row mx-0 my-3 py-3 bg-light",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "col-md-3",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("h5", {
        className: "text-secondary",
        children: "Filter Products"
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "col-md-3",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
        className: "form-control",
        ref: titleFilter,
        type: "text",
        placeholder: "Filter by title",
        value: filterTitle,
        onChange: changeTitle
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "col-md-3",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
        list: "brands",
        className: "form-control",
        ref: brandFilter,
        placeholder: "Filter by brand",
        value: filterBrand,
        onChange: changeBrand
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("datalist", {
        id: "brands",
        children: BrandsArray && BrandsArray.map((brand, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: brand.name
        }, i))
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "col-md-3",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
        list: "categories",
        className: "form-control",
        ref: categoryFilter,
        placeholder: "Filter by category",
        value: filterCategory,
        onChange: changeCategory
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("datalist", {
        id: "categories",
        children: categoriesArray && categoriesArray.map((category, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: category.name
        }, i))
      })]
    })]
  });
}
// CONCATENATED MODULE: ./components/homeComponents/slider.tsx




function Slider({
  slider
}) {
  const {
    0: index,
    1: setIndex
  } = Object(external_react_["useState"])(0);

  const handleSelect = selectedIndex => {
    setIndex(selectedIndex);
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Carousel"], {
    activeIndex: index,
    onSelect: handleSelect,
    children: slider.map((slide, i) => /*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_react_bootstrap_["Carousel"].Item, {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
        className: "d-block w-100",
        src: slide.image,
        alt: slide === null || slide === void 0 ? void 0 : slide.title
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_react_bootstrap_["Carousel"].Caption, {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
          children: slide === null || slide === void 0 ? void 0 : slide.title
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
          children: slide === null || slide === void 0 ? void 0 : slide.description
        })]
      })]
    }, i))
  });
}
// EXTERNAL MODULE: ./styles/aboutHome.module.css
var aboutHome_module = __webpack_require__("QVBc");
var aboutHome_module_default = /*#__PURE__*/__webpack_require__.n(aboutHome_module);

// CONCATENATED MODULE: ./components/homeComponents/homeAbout.tsx





function HomeAbout({
  about
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: `row mx-0 p-5 ${aboutHome_module_default.a.aboutHome}`,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h1", {
      className: "w-100",
      children: about.title
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
      className: "container my-3 px-5 text-justify text-center",
      children: about.description
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "container",
      style: {
        zIndex: 99
      },
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
        href: "/about",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
          className: `btn btnInvertOutline`,
          children: t("ReadMore")
        })
      })
    })]
  });
}
// EXTERNAL MODULE: external "react-multi-carousel"
var external_react_multi_carousel_ = __webpack_require__("99J/");
var external_react_multi_carousel_default = /*#__PURE__*/__webpack_require__.n(external_react_multi_carousel_);

// EXTERNAL MODULE: ./node_modules/react-multi-carousel/lib/styles.css
var styles = __webpack_require__("VLDe");

// CONCATENATED MODULE: ./components/homeComponents/brandSlider.tsx




function BrandSlider(props) {
  const responsive = {
    desktop: {
      breakpoint: {
        max: 3000,
        min: 1024
      },
      items: 4,
      slidesToSlide: 1 // optional, default to 1.

    },
    tablet: {
      breakpoint: {
        max: 1024,
        min: 464
      },
      items: 2,
      slidesToSlide: 1 // optional, default to 1.

    },
    mobile: {
      breakpoint: {
        max: 464,
        min: 0
      },
      items: 1,
      slidesToSlide: 1 // optional, default to 1.

    }
  };
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_multi_carousel_default.a, {
    swipeable: true,
    draggable: false,
    showDots: false,
    responsive: responsive,
    ssr: true // means to render carousel on server-side.
    ,
    infinite: true,
    autoPlay: props.deviceType !== "mobile" ? true : false,
    autoPlaySpeed: 3000,
    keyBoardControl: true,
    customTransition: "all .5",
    transitionDuration: 500,
    containerClass: "carousel-container d-flex justify-content-center",
    removeArrowOnDeviceType: ["tablet", "mobile"],
    deviceType: props.deviceType,
    itemClass: "carousel-item-padding-40-px mx-0",
    children: props.sliderItems.map((item, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
      href: `/products?type=brand&q=${item.name}`,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("a", {
        className: "brand-img",
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
          src: item.image,
          alt: item.name,
          width: 100
        })
      })
    }, i))
  });
}
// CONCATENATED MODULE: ./components/adminLayout.tsx





function AdminLayout({
  children
}) {
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(jsx_runtime_["Fragment"], {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])(head_default.a, {
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("title", {
        children: "International Export :: Admin Panel"
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("link", {
        rel: "icon",
        href: "/fav.png"
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(AdminHeader, {}), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "d-flex mx-0",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(SideMenu, {}), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "content-warper",
        children: children
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(AdminFooter, {})]
  });
}
// EXTERNAL MODULE: ./styles/adminHeader.module.css
var adminHeader_module = __webpack_require__("1XTA");
var adminHeader_module_default = /*#__PURE__*/__webpack_require__.n(adminHeader_module);

// CONCATENATED MODULE: ./components/adminHeader.tsx









function AdminHeader() {
  const {
    t
  } = Object(localHook["a" /* default */])();
  const {
    0: modalType
  } = Object(external_react_["useState"])("changePassword");
  const router = Object(router_["useRouter"])();
  const {
    0: show,
    1: setShow
  } = Object(external_react_["useState"])(false);

  const handleClose = () => setShow(false);

  const handleShow = () => setShow(true);

  const {
    0: user,
    1: setUser
  } = Object(external_react_["useState"])();
  Object(external_react_["useEffect"])(() => {
    if (typeof Storage !== 'undefined') {
      setUser(JSON.parse(localStorage.getItem('user')));
    }
  }, []);

  const logoutHandler = async e => {
    e.preventDefault();

    try {
      const resp = await fetch('/api/users/signout', {
        method: 'POST' // headers: {
        //   'Content-Type': 'application/json'
        // },

      });
      const json = await resp.json();
      if (typeof Storage !== 'undefined') localStorage.removeItem('user');
      router.push('/admin/login');
    } catch (e) {
      console.log(e.message);
    }
  };

  const ChangePassword = async item => {
    try {
      const res = await fetch('/api/users/changePassword', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          id: user.id,
          old_password: item.old_password,
          password: item.password
        })
      });
      const json = await res.json();
      if (!res.ok) throw Error(json.message); // dispatchRoles(addRole({id: json.insertId ,...item, isDeleted : 0}))

      handleClose();
    } catch (e) {
      throw Error(e.message);
    }
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: `bg-light py-2 px-5 ${adminHeader_module_default.a.header} `,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h3", {
      className: "my-3 text-danger",
      children: "International Export"
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("ul", {
      className: "nav",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("li", {
        className: "nav-item mx-2",
        children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("button", {
          className: "btn mt-3",
          onClick: e => {
            e.preventDefault();
            handleShow();
          },
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
            icon: free_solid_svg_icons_["faUser"],
            color: "#888",
            style: {
              width: '15px',
              marginRight: '10px',
              marginTop: '0'
            }
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
            children: user && (user === null || user === void 0 ? void 0 : user.userName)
          })]
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("li", {
        className: "nav-item mx-2",
        children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("button", {
          className: "btn mt-3",
          onClick: logoutHandler,
          children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
            icon: free_solid_svg_icons_["faSignOutAlt"],
            color: "#888",
            style: {
              width: '15px',
              marginRight: '10px',
              marginTop: '0'
            }
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
            children: "Logout"
          })]
        })
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(AdminModal, {
      show: show,
      handleClose: handleClose,
      formTitle: modalType === 'changePassword' ? t('ChangePassword') : '',
      FormComponent: modalType === 'changePassword' ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(ChangePasswordForm, {
        handleChange: ChangePassword,
        handleClose: handleClose
      }) : /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {})
    })]
  });
}
// EXTERNAL MODULE: ./styles/sideMenu.module.css
var sideMenu_module = __webpack_require__("07Px");
var sideMenu_module_default = /*#__PURE__*/__webpack_require__.n(sideMenu_module);

// CONCATENATED MODULE: ./components/sideMenu.tsx









function SideMenu() {
  const {
    0: collapsed,
    1: setCollapsed
  } = Object(external_react_["useState"])(false);
  const router = Object(router_["useRouter"])();
  const {
    t
  } = Object(localHook["a" /* default */])();

  const toggleMenu = e => {
    setCollapsed(!collapsed);
  };

  const menuItems = [{
    title: t('About'),
    link: '/admin/about',
    icon: free_solid_svg_icons_["faInfoCircle"]
  }, {
    title: t('Slide'),
    link: '/admin/slide',
    icon: free_solid_svg_icons_["faImages"]
  }, {
    title: t('Categories'),
    link: '/admin/categories',
    icon: free_solid_svg_icons_["faPuzzlePiece"]
  }, {
    title: t('AdBrands'),
    link: '/admin/brands',
    icon: free_solid_svg_icons_["faCopyright"]
  }, {
    title: t('AdProducts'),
    link: '/admin/products',
    icon: free_solid_svg_icons_["faCar"]
  }, {
    title: t('Contact'),
    link: '/admin/contacts',
    icon: free_solid_svg_icons_["faPhoneAlt"]
  } // {
  //   title: t('Users'),
  //   link: '/admin/users',
  //   icon: faUsers
  // },
  // {
  //   title: t('Roles'),
  //   link: '/admin/roles',
  //   icon: faUserTag
  // }
  ];
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: !collapsed ? sideMenu_module_default.a.sideMenu : sideMenu_module_default.a.sideMenuCollapsed,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
      className: `btn my-3 mx-2 ${sideMenu_module_default.a.toggleBtn}`,
      onClick: toggleMenu,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
        icon: !collapsed ? free_solid_svg_icons_["faTimes"] : free_solid_svg_icons_["faBars"],
        color: "#003A5E",
        style: {
          width: '15px'
        }
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("ul", {
      className: sideMenu_module_default.a.sideMenuUl,
      children: menuItems.map((item, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("li", {
        className: `${router.pathname === item.link ? sideMenu_module_default.a.sideItemActive : sideMenu_module_default.a.sideItem}`,
        children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(link_default.a, {
          href: item.link,
          children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("a", {
            className: sideMenu_module_default.a.sideLink,
            children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
              icon: item.icon,
              style: collapsed ? {
                width: '25px',
                marginLeft: '5px'
              } : {
                width: '18px'
              }
            }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("span", {
              className: `mx-3 ${collapsed && 'd-none'}`,
              children: [" ", item.title, " "]
            })]
          })
        })
      }, i))
    })]
  });
}
// CONCATENATED MODULE: ./components/adminFooter.tsx


function AdminFooter() {
  const {
    t
  } = Object(localHook["a" /* default */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("footer", {
    className: "row mx-0 bg-light text-dark border-top p-3 justify-content-center",
    children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("small", {
      children: t("CopyRights")
    })
  });
}
// CONCATENATED MODULE: ./components/adminSectionHeader.tsx





function AdminSectionHeader({
  sectionName,
  handleAdd
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
    className: "row justify-content-between",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("h1", {
      className: "textPrimary mt-3",
      children: sectionName
    }), sectionName !== t('About') && sectionName !== t('Contact') ? /*#__PURE__*/Object(jsx_runtime_["jsxs"])("button", {
      className: "btn btnPrimary",
      onClick: handleAdd,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
        icon: free_solid_svg_icons_["faPlus"],
        color: "#FFF",
        style: {
          width: '15px',
          marginRight: '0.7rem'
        }
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
        children: t('Add')
      })]
    }) : null]
  });
}
// CONCATENATED MODULE: ./components/adminTable.tsx



function AdminTable({
  tableTitles,
  items,
  restoreItem,
  handleDelete,
  handleEdit
}) {
  const cols = items === null || items === void 0 ? void 0 : items.map(item => Object.values(item));
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: "row",
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("table", {
      className: "table",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("thead", {
        className: "thead-dark",
        children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("tr", {
          children: [tableTitles.map((title, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("th", {
            scope: "col",
            children: title
          }, i)), /*#__PURE__*/Object(jsx_runtime_["jsx"])("th", {
            scope: "col"
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("th", {
            scope: "col"
          })]
        })
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("tbody", {
        children: cols.length > 0 ? cols === null || cols === void 0 ? void 0 : cols.map((item, i) => /*#__PURE__*/Object(jsx_runtime_["jsxs"])("tr", {
          className: item[item.length - 1] == true ? 'alert-danger' : '',
          children: [item.map((col, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("td", {
            children: col
          }, i)), /*#__PURE__*/Object(jsx_runtime_["jsx"])("td", {
            children: !item[item.length - 1] ? /*#__PURE__*/Object(jsx_runtime_["jsx"])(DeleteBtn, {
              handleDelete: () => handleDelete(items.find(tItem => tItem.id == item[0]))
            }) : /*#__PURE__*/Object(jsx_runtime_["jsx"])(ActiveBtn, {
              restoreItem: () => restoreItem(items.find(tItem => tItem.id == item[0]))
            })
          }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("td", {
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(EditBtn, {
              handleEdit: () => handleEdit(items.find(tItem => tItem.id == item[0]))
            })
          })]
        }, i)) : /*#__PURE__*/Object(jsx_runtime_["jsx"])("tr", {
          children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("td", {
            colSpan: tableTitles.length,
            children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("h5", {
              className: "w-100 text-center my-3",
              children: "No data here!"
            })
          })
        })
      })]
    })
  });
}
// CONCATENATED MODULE: ./components/adminByDelete.tsx



function AdmenFilterByDelete({
  filterDelete,
  filterChange,
  filterRef
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
    className: "row d-flex flex-row-reverse",
    children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "col-md-4 py-3 d-flex",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        className: "w-25 mt-2 text-secondary",
        children: t('FilterDelete')
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("select", {
        className: "form-control",
        ref: filterRef,
        defaultValue: filterDelete,
        onChange: filterChange,
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: "0",
          children: t('All')
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: "false",
          children: t("ActiveItem")
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: "true",
          children: t("DeleteItem")
        })]
      })]
    })
  });
}
// CONCATENATED MODULE: ./components/adminModal.tsx



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


function AdminModal(_ref) {
  let {
    show,
    handleClose,
    FormComponent,
    formTitle
  } = _ref,
      props = _objectWithoutProperties(_ref, ["show", "handleClose", "FormComponent", "formTitle"]);

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(external_react_bootstrap_["Modal"], _objectSpread(_objectSpread({
    show: show,
    onHide: handleClose
  }, props), {}, {
    size: "xl",
    centered: true,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Modal"].Header, {
      closeButton: true,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Modal"].Title, {
        children: formTitle
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(external_react_bootstrap_["Modal"].Body, {
      children: FormComponent
    })]
  }));
}
// CONCATENATED MODULE: ./components/utilities/editButton.tsx





function EditBtn({
  handleEdit
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("button", {
    className: "btn btn-primary",
    onClick: handleEdit,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
      icon: free_solid_svg_icons_["faPencilAlt"],
      color: "#FFF",
      style: {
        width: '15px',
        marginRight: '0.7rem'
      }
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
      children: t('Edit')
    })]
  });
}
// CONCATENATED MODULE: ./components/utilities/deleteButton.tsx





function DeleteBtn({
  handleDelete
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("button", {
    className: "btn btn-danger",
    onClick: handleDelete,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
      icon: free_solid_svg_icons_["faTimes"],
      color: "#FFF",
      style: {
        width: '15px',
        marginRight: '0.7rem'
      }
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
      children: t('Delete')
    })]
  });
}
// CONCATENATED MODULE: ./components/utilities/activeButton.tsx





function ActiveBtn({
  restoreItem
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("button", {
    className: "btn btn-success",
    onClick: restoreItem,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
      icon: free_solid_svg_icons_["faRedo"],
      color: "#FFF",
      style: {
        width: '15px',
        marginRight: '0.7rem'
      }
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
      children: t('RestoreItem')
    })]
  });
}
// CONCATENATED MODULE: ./components/forms/confirmDelete.tsx




function ConfirmDelete({
  handleClose,
  confirmDelete
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])(jsx_runtime_["Fragment"], {
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("p", {
      className: "text-danger text-center",
      children: t('ConfirmMessage')
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "d-flex justify-content-center",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        className: "btn btn-secondary mx-2",
        onClick: handleClose,
        children: t('Cancel')
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        className: "btn btn-danger mx-2",
        onClick: confirmDelete,
        children: t('Delete')
      })]
    })]
  });
}
// EXTERNAL MODULE: external "formik"
var external_formik_ = __webpack_require__("QxnH");

// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__("C8TP");

// CONCATENATED MODULE: ./components/forms/categoryForm.tsx



function categoryForm_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function categoryForm_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { categoryForm_ownKeys(Object(source), true).forEach(function (key) { categoryForm_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { categoryForm_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function categoryForm_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




function CategoryForm({
  type,
  item,
  handleClose,
  editItem,
  addItem
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  const formik = Object(external_formik_["useFormik"])({
    initialValues: {
      title: type === 'add' ? '' : item.title,
      title_ar: type === 'add' ? '' : item.title_ar
    },
    validationSchema: external_yup_["object"]({
      title: external_yup_["string"]().required('Required'),
      title_ar: external_yup_["string"]().required('required')
    }),
    onSubmit: values => {
      type === 'add' ? addItem({
        title: values.title,
        title_ar: values.title_ar,
        createdAt: new Date().toLocaleString(),
        updatedAt: new Date().toLocaleString(),
        isDeleted: false
      }) : editItem(categoryForm_objectSpread(categoryForm_objectSpread({}, item), {}, {
        title: values.title,
        title_ar: values.title_ar
      }));
    }
  });
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("form", {
    className: "my-4 row",
    onSubmit: formik.handleSubmit,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("EnglishName")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", categoryForm_objectSpread(categoryForm_objectSpread({
        type: "text",
        className: "form-control",
        id: "title"
      }, formik.getFieldProps('title')), {}, {
        placeholder: t("EnglishName")
      })), formik.touched.title && formik.errors.title ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.title
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      style: {
        position: 'relative'
      },
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("ArabicName")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", categoryForm_objectSpread(categoryForm_objectSpread({
        type: "text",
        id: "title_ar",
        className: "form-control"
      }, formik.getFieldProps('title_ar')), {}, {
        placeholder: t("ArabicName")
      })), formik.touched.title_ar && formik.errors.title_ar ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.title_ar
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group mx-auto",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
        type: "submit",
        className: "btn btn-primary mx-3",
        value: type === 'add' ? t('Add') : t('Edit')
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        type: "button",
        className: "btn btn-secondary mx-3",
        onClick: handleClose,
        children: t('Cancel')
      })]
    })]
  });
}
// CONCATENATED MODULE: ./components/forms/brandForm.tsx



function brandForm_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function brandForm_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { brandForm_ownKeys(Object(source), true).forEach(function (key) { brandForm_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { brandForm_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function brandForm_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function BrandForm({
  type,
  item,
  handleClose,
  editItem,
  addItem
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  const {
    0: picFile,
    1: setPicFile
  } = Object(external_react_["useState"])();

  const setFile = file => setPicFile(file);

  const getBase = pic => formik.values.image = pic;

  const formik = Object(external_formik_["useFormik"])({
    initialValues: {
      title: type === 'add' ? '' : item.title,
      title_ar: type === 'add' ? '' : item.title_ar,
      image: type === 'add' ? null : item.image
    },
    validationSchema: external_yup_["object"]({
      title: external_yup_["string"]().required('Required'),
      title_ar: external_yup_["string"]().required('required')
    }),
    onSubmit: values => {
      type === 'add' ? addItem({
        title: values.title,
        title_ar: values.title_ar,
        image: values.image,
        picFile: picFile,
        createdAt: new Date().toLocaleString(),
        updatedAt: new Date().toLocaleString(),
        isDeleted: false
      }) : editItem(brandForm_objectSpread(brandForm_objectSpread({}, item), {}, {
        title: values.title,
        title_ar: values.title_ar,
        image: values.image,
        picFile: picFile,
        updatedAt: new Date().toLocaleString()
      }));
    }
  });
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("form", {
    className: "my-4 row",
    onSubmit: formik.handleSubmit,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("EnglishName")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", brandForm_objectSpread(brandForm_objectSpread({
        type: "text",
        className: "form-control",
        id: "title"
      }, formik.getFieldProps('title')), {}, {
        placeholder: t("EnglishName")
      })), formik.touched.title && formik.errors.title ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.title
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      style: {
        position: 'relative'
      },
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("ArabicName")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", brandForm_objectSpread(brandForm_objectSpread({
        type: "text",
        id: "title_ar",
        className: "form-control"
      }, formik.getFieldProps('title_ar')), {}, {
        placeholder: t("ArabicName")
      })), formik.touched.title_ar && formik.errors.title_ar ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.title_ar
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(UploadImage, {
      picUrl: formik.values.image,
      setFile: setFile,
      getBase: getBase
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group mx-auto",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
        type: "submit",
        className: "btn btn-primary mx-3",
        value: type === 'add' ? t('Add') : t('Edit')
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        type: "button",
        className: "btn btn-secondary mx-3",
        onClick: handleClose,
        children: t('Cancel')
      })]
    })]
  });
}
// EXTERNAL MODULE: ./styles/upload.module.css
var upload_module = __webpack_require__("RdaU");
var upload_module_default = /*#__PURE__*/__webpack_require__.n(upload_module);

// CONCATENATED MODULE: ./components/forms/uploadImage.tsx



function uploadImage_objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = uploadImage_objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function uploadImage_objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





function UploadImage(_ref) {
  let {
    picUrl,
    setFile
  } = _ref,
      props = uploadImage_objectWithoutProperties(_ref, ["picUrl", "setFile"]);

  const SUPPORTED_FORMATS = [".jpg", ".gif", ".png", ".gif"];
  const FILE_SIZE = 10000;
  const imageRef = Object(external_react_["useRef"])();
  const {
    0: picURL,
    1: setPicURL
  } = Object(external_react_["useState"])(picUrl);
  const {
    0: picture,
    1: setPicture
  } = Object(external_react_["useState"])(null);

  const handleUpload = e => {
    e.preventDefault();
    let file = e.target.files[0];
    let reader = new FileReader();
    reader.readAsDataURL(file);

    reader.onloadend = () => {
      setPicture(reader.result); //this.handleSubmit()

      setFile(reader.result);
      setPicURL(null);
      props.getBase && props.getBase(reader.result);
    };
  };

  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("label", {
    className: upload_module_default.a.componentContainer,
    htmlFor: "image",
    children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
      type: "file",
      id: "image",
      className: upload_module_default.a.imgInput,
      onChange: handleUpload,
      ref: imageRef
    }), !picture && !picURL ? /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: upload_module_default.a.uploadDiv,
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])(react_fontawesome_["FontAwesomeIcon"], {
        icon: free_solid_svg_icons_["faCloudUploadAlt"],
        color: "#dc3545",
        style: {
          width: '50px',
          marginRight: '0.7rem'
        }
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("span", {
        className: "my-3 text-danger",
        children: "Click to Select Picture"
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("small", {
        className: "my-2",
        children: ["Files allowed : ", JSON.stringify(SUPPORTED_FORMATS)]
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("small", {
        children: ["Max File Size ", FILE_SIZE]
      })]
    }) : picURL ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: upload_module_default.a.uploadDiv,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
        src: picURL,
        width: 300,
        height: 300,
        alt: "pic"
      })
    }) : /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: upload_module_default.a.uploadDiv,
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])("img", {
        src: picture.toString(),
        className: "w-100"
      })
    })]
  });
}
// CONCATENATED MODULE: ./components/forms/sliderForm.tsx



function sliderForm_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function sliderForm_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { sliderForm_ownKeys(Object(source), true).forEach(function (key) { sliderForm_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { sliderForm_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function sliderForm_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function SliderForm({
  type,
  item,
  handleClose,
  editItem,
  addItem
}) {
  const {
    0: picFile,
    1: setPicFile
  } = Object(external_react_["useState"])();
  const {
    t
  } = Object(localHook["a" /* default */])();

  const setFile = file => setPicFile(file);

  const getBase = pic => formik.values.image = pic;

  const formik = Object(external_formik_["useFormik"])({
    initialValues: {
      title: type === 'add' ? '' : item.title,
      title_ar: type === 'add' ? '' : item.title_ar,
      description: type === 'add' ? '' : item.description,
      description_ar: type === 'add' ? '' : item.description_ar,
      image: type === 'add' ? null : item.image
    },
    validationSchema: external_yup_["object"]({
      title: external_yup_["string"](),
      title_ar: external_yup_["string"](),
      description: external_yup_["string"](),
      description_ar: external_yup_["string"]()
    }),
    onSubmit: values => {
      type === 'add' ? addItem({
        title: values.title,
        title_ar: values.title_ar,
        image: values.image,
        //picFile: picFile ,
        description: values.description,
        description_ar: values.description_ar
      }) : editItem(sliderForm_objectSpread(sliderForm_objectSpread({}, item), {}, {
        title: values.title,
        title_ar: values.title_ar,
        image: values.image,
        //picFile: picFile ,
        description: values.description,
        description_ar: values.description_ar
      }));
    }
  });
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("form", {
    className: "my-4 row",
    onSubmit: formik.handleSubmit,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("EnglishName")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", sliderForm_objectSpread(sliderForm_objectSpread({
        type: "text",
        className: "form-control",
        id: "title"
      }, formik.getFieldProps('title')), {}, {
        placeholder: t("EnglishName")
      }))]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      style: {
        position: 'relative'
      },
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("ArabicName")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", sliderForm_objectSpread(sliderForm_objectSpread({
        type: "text",
        id: "title_ar",
        className: "form-control"
      }, formik.getFieldProps('title_ar')), {}, {
        placeholder: t("ArabicName")
      }))]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("Description")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", sliderForm_objectSpread(sliderForm_objectSpread({
        type: "text",
        className: "form-control",
        id: "description"
      }, formik.getFieldProps('description')), {}, {
        placeholder: t("Description")
      }))]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      style: {
        position: 'relative'
      },
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("ArDescription")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", sliderForm_objectSpread(sliderForm_objectSpread({
        type: "text",
        id: "description_ar",
        className: "form-control"
      }, formik.getFieldProps('description_ar')), {}, {
        placeholder: t("ArDescription")
      }))]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "form-group col-md-12",
      children: /*#__PURE__*/Object(jsx_runtime_["jsx"])(UploadImage, {
        picUrl: formik.values.image,
        setFile: setFile,
        getBase: getBase
      })
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group mx-auto",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
        type: "submit",
        className: "btn btn-primary mx-3",
        value: type === 'add' ? t('Add') : t('Edit')
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        type: "button",
        className: "btn btn-secondary mx-3",
        onClick: handleClose,
        children: t('Cancel')
      })]
    })]
  });
}
// CONCATENATED MODULE: ./components/forms/rolesForm.tsx



function rolesForm_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function rolesForm_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { rolesForm_ownKeys(Object(source), true).forEach(function (key) { rolesForm_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { rolesForm_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function rolesForm_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




function RolesForm({
  type,
  item,
  handleClose,
  editItem,
  addItem
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  const formik = Object(external_formik_["useFormik"])({
    initialValues: {
      title: type === 'add' ? '' : item.title,
      title_ar: type === 'add' ? '' : item.title_ar
    },
    validationSchema: external_yup_["object"]({
      title: external_yup_["string"]().required('Required'),
      title_ar: external_yup_["string"]().required('required')
    }),
    onSubmit: values => {
      type === 'add' ? addItem({
        title: values.title,
        title_ar: values.title_ar,
        createdAt: new Date().toLocaleString(),
        updatedAt: new Date().toLocaleString(),
        isDeleted: false
      }) : editItem(rolesForm_objectSpread(rolesForm_objectSpread({}, item), {}, {
        title: values.title,
        title_ar: values.title_ar
      }));
    }
  });
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("form", {
    className: "my-4 row",
    onSubmit: formik.handleSubmit,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("EnglishName")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", rolesForm_objectSpread(rolesForm_objectSpread({
        type: "text",
        className: "form-control",
        id: "title"
      }, formik.getFieldProps('title')), {}, {
        placeholder: t("EnglishName")
      })), formik.touched.title && formik.errors.title ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.title
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      style: {
        position: 'relative'
      },
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("ArabicName")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", rolesForm_objectSpread(rolesForm_objectSpread({
        type: "text",
        id: "title_ar",
        className: "form-control"
      }, formik.getFieldProps('title_ar')), {}, {
        placeholder: t("ArabicName")
      })), formik.touched.title_ar && formik.errors.title_ar ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.title_ar
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group mx-auto",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
        type: "submit",
        className: "btn btn-primary mx-3",
        value: type === 'add' ? t('Add') : t('Edit')
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        type: "button",
        className: "btn btn-secondary mx-3",
        onClick: handleClose,
        children: t('Cancel')
      })]
    })]
  });
}
// CONCATENATED MODULE: ./components/forms/usersForm.tsx



function usersForm_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function usersForm_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { usersForm_ownKeys(Object(source), true).forEach(function (key) { usersForm_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { usersForm_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function usersForm_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




function UserForm({
  type,
  item,
  handleClose,
  editItem,
  addItem,
  rolesProps
}) {
  var _rolesProps$find;

  const {
    t
  } = Object(localHook["a" /* default */])();
  const formik = Object(external_formik_["useFormik"])({
    initialValues: {
      userName: type === 'add' ? '' : item.userName,
      email: type === 'add' ? '' : item.email,
      password: '',
      role: type === 'add' ? '' : (_rolesProps$find = rolesProps.find(role => role.role === item.role)) === null || _rolesProps$find === void 0 ? void 0 : _rolesProps$find.id
    },
    validationSchema: external_yup_["object"]({
      userName: external_yup_["string"]().required('Required'),
      email: external_yup_["string"]().required('required'),
      password: type === 'add' && external_yup_["string"]().min(8, 'Password must be 8 letters at least'),
      role: external_yup_["string"]().required('required')
    }),
    onSubmit: values => {
      type === 'add' ? addItem({
        userName: values.userName,
        email: values.email,
        password: values.password,
        role: values.role,
        createdAt: new Date().toLocaleString(),
        updatedAt: new Date().toLocaleString(),
        isDeleted: false
      }) : editItem(usersForm_objectSpread(usersForm_objectSpread({}, item), {}, {
        role: values.role
      }));
    }
  });
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("form", {
    className: "my-4 row",
    onSubmit: formik.handleSubmit,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("UserName")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", usersForm_objectSpread(usersForm_objectSpread({
        type: "text",
        className: "form-control",
        id: "userName"
      }, formik.getFieldProps('userName')), {}, {
        disabled: type === 'edit',
        placeholder: t("EnglishName")
      })), formik.touched.userName && formik.errors.userName ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.userName
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      style: {
        position: 'relative'
      },
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("EmailTitle")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", usersForm_objectSpread(usersForm_objectSpread({
        type: "text",
        id: "email",
        className: "form-control",
        disabled: type === 'edit'
      }, formik.getFieldProps('email')), {}, {
        placeholder: t("EmailTitle")
      })), formik.touched.email && formik.errors.email ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.email
      }) : null]
    }), type === 'add' && /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      style: {
        position: 'relative'
      },
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("Password")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", usersForm_objectSpread(usersForm_objectSpread({
        type: "password",
        id: "password",
        className: "form-control"
      }, formik.getFieldProps('password')), {}, {
        placeholder: t("Password")
      })), formik.touched.email && formik.errors.email ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.email
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      style: {
        position: 'relative'
      },
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("Roles")
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("select", usersForm_objectSpread(usersForm_objectSpread({
        id: "role",
        className: "form-control"
      }, formik.getFieldProps('role')), {}, {
        placeholder: t("Roles"),
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: "",
          disabled: true,
          children: "Select Role"
        }), rolesProps.map((role, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: role.id,
          children: role.role
        }, i))]
      })), formik.touched.role && formik.errors.role ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.role
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-12 d-block",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
        type: "submit",
        className: "btn btn-primary mx-3",
        value: type === 'add' ? t('Add') : t('Edit')
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        type: "button",
        className: "btn btn-secondary mx-3",
        onClick: handleClose,
        children: t('Cancel')
      })]
    })]
  });
}
// CONCATENATED MODULE: ./components/forms/productForm.tsx



function productForm_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function productForm_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { productForm_ownKeys(Object(source), true).forEach(function (key) { productForm_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { productForm_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function productForm_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





 // import SunEditor from 'suneditor-react';


function ProductsForm({
  type,
  item,
  handleClose,
  editItem,
  addItem,
  categories,
  brandsProps
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  const {
    0: picFile,
    1: setPicFile
  } = Object(external_react_["useState"])();

  const setFile = file => setPicFile(file);

  const getBase = pic => formik.values.image = pic;

  const formik = Object(external_formik_["useFormik"])({
    initialValues: {
      title: type === 'add' ? '' : item.title,
      title_ar: type === 'add' ? '' : item.title_ar,
      description: type === 'add' ? '' : item.description,
      description_ar: type === 'add' ? '' : item.description_ar,
      details: type === 'add' ? '' : item.details,
      details_ar: type === 'add' ? '' : item.details_ar,
      ct_id: type === 'add' ? '' : item.ct_id,
      br_id: type === 'add' ? '' : item.br_id,
      keyWords: type === 'add' ? '' : item.keyWords,
      image: type === 'add' ? null : item.image
    },
    validationSchema: external_yup_["object"]({
      title: external_yup_["string"]().required('Required'),
      title_ar: external_yup_["string"]().required('required'),
      description: external_yup_["string"]().required('required'),
      description_ar: external_yup_["string"]().required('required'),
      details: external_yup_["string"]().required('required'),
      details_ar: external_yup_["string"]().required('required'),
      ct_id: external_yup_["string"]().required('required'),
      br_id: external_yup_["string"]().required('required'),
      keyWords: external_yup_["string"]().required('required')
    }),
    onSubmit: values => {
      type === 'add' ? addItem({
        title: values.title,
        title_ar: values.title_ar,
        description: values.description,
        description_ar: values.description_ar,
        details: values.details,
        details_ar: values.details_ar,
        ct_id: Number(values.ct_id),
        br_id: Number(values.br_id),
        keyWords: values.keyWords,
        image: values.image,
        picFile: picFile
      }) : editItem(productForm_objectSpread(productForm_objectSpread({}, item), {}, {
        title: values.title,
        title_ar: values.title_ar,
        description: values.description,
        description_ar: values.description_ar,
        details: values.details,
        details_ar: values.details_ar,
        ct_id: Number(values.ct_id),
        br_id: Number(values.br_id),
        keyWords: values.keyWords,
        image: values.image,
        picFile: picFile
      }));
    }
  });
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("form", {
    className: "my-4 row",
    onSubmit: formik.handleSubmit,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("EnglishName")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", productForm_objectSpread(productForm_objectSpread({
        type: "text",
        className: "form-control",
        id: "title"
      }, formik.getFieldProps('title')), {}, {
        placeholder: t("EnglishName")
      })), formik.touched.title && formik.errors.title ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.title
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      style: {
        position: 'relative'
      },
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("ArabicName")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", productForm_objectSpread(productForm_objectSpread({
        type: "text",
        id: "title_ar",
        className: "form-control"
      }, formik.getFieldProps('title_ar')), {}, {
        placeholder: t("ArabicName")
      })), formik.touched.title_ar && formik.errors.title_ar ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.title_ar
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-12",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("Description")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", productForm_objectSpread(productForm_objectSpread({
        type: "text",
        className: "form-control",
        id: "description"
      }, formik.getFieldProps('description')), {}, {
        placeholder: t("Description")
      })), formik.touched.description && formik.errors.description ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.description
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-12",
      style: {
        position: 'relative'
      },
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("ArDescription")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", productForm_objectSpread(productForm_objectSpread({
        type: "text",
        id: "description_ar",
        className: "form-control"
      }, formik.getFieldProps('description_ar')), {}, {
        placeholder: t("ArDescription")
      })), formik.touched.description_ar && formik.errors.description_ar ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.description_ar
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-12",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        htmlFor: "details",
        children: t('Details')
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("textarea", productForm_objectSpread(productForm_objectSpread({
        rows: 8,
        id: "details",
        className: "form-control"
      }, formik.getFieldProps('details')), {}, {
        placeholder: t("Details")
      })), formik.touched.details && formik.errors.details ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.details
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-12",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        htmlFor: "details_ar",
        children: t('ArDetails')
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("textarea", productForm_objectSpread(productForm_objectSpread({
        rows: 8,
        id: "details_ar",
        className: "form-control"
      }, formik.getFieldProps('details_ar')), {}, {
        placeholder: t("ArDetails")
      })), formik.touched.details_ar && formik.errors.details_ar ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.details_ar
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        htmlFor: "ct_id",
        children: t('Categories')
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("select", productForm_objectSpread(productForm_objectSpread({
        className: "form-control",
        value: "",
        id: "ct_id"
      }, formik.getFieldProps('ct_id')), {}, {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: "",
          disabled: true,
          children: "Select Category"
        }), categories === null || categories === void 0 ? void 0 : categories.map((c, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: c.id,
          children: c.title
        }, i))]
      })), formik.touched.ct_id && formik.errors.ct_id ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.ct_id
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        htmlFor: "br_id",
        children: t('Brands')
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("select", productForm_objectSpread(productForm_objectSpread({
        className: "form-control",
        id: "br_id",
        value: ""
      }, formik.getFieldProps('br_id')), {}, {
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: "",
          disabled: true,
          children: "Select Category"
        }), brandsProps === null || brandsProps === void 0 ? void 0 : brandsProps.map((b, i) => /*#__PURE__*/Object(jsx_runtime_["jsx"])("option", {
          value: b.id,
          children: b.title
        }, i))]
      })), formik.touched.br_id && formik.errors.br_id ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.br_id
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-12",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        htmlFor: "keyWords",
        children: t('KeyWords')
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", productForm_objectSpread({
        type: "text",
        className: "form-control",
        id: "keyWords"
      }, formik.getFieldProps('keyWords'))), formik.touched.keyWords && formik.errors.keyWords ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.keyWords
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])(UploadImage, {
      picUrl: formik.values.image,
      setFile: setFile,
      getBase: getBase
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group mx-auto",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
        type: "submit",
        className: "btn btn-primary mx-3",
        value: type === 'add' ? t('Add') : t('Edit')
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
        type: "button",
        className: "btn btn-secondary mx-3",
        onClick: handleClose,
        children: t('Cancel')
      })]
    })]
  });
}
// CONCATENATED MODULE: ./components/forms/changePassForm.tsx



function changePassForm_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function changePassForm_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { changePassForm_ownKeys(Object(source), true).forEach(function (key) { changePassForm_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { changePassForm_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function changePassForm_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




function ChangePasswordForm({
  handleChange,
  handleClose
}) {
  const {
    t
  } = Object(localHook["a" /* default */])();
  const formik = Object(external_formik_["useFormik"])({
    initialValues: {
      old_password: '',
      password: '',
      cPassword: ''
    },
    validationSchema: external_yup_["object"]({
      old_password: external_yup_["string"]().required('Old Password Required'),
      password: external_yup_["string"]().required('Password is required'),
      cPassword: external_yup_["string"]().oneOf([external_yup_["ref"]('password'), null], 'Passwords must match')
    }),
    onSubmit: values => {
      handleChange({
        old_password: values.old_password,
        password: values.password,
        cPassword: values.cPassword
      });
    }
  });
  return /*#__PURE__*/Object(jsx_runtime_["jsxs"])("form", {
    className: "my-4",
    onSubmit: formik.handleSubmit,
    children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "form-group col-md-6",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
        children: t("OldPassword")
      }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", changePassForm_objectSpread(changePassForm_objectSpread({
        type: "password",
        className: "form-control",
        id: "old_password"
      }, formik.getFieldProps('old_password')), {}, {
        placeholder: t("OldPassword")
      })), formik.touched.old_password && formik.errors.old_password ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
        className: "alert alert-danger my-3",
        role: "alert",
        children: formik.errors.old_password
      }) : null]
    }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
      className: "row col-12",
      children: [/*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: "form-group col-md-6",
        style: {
          position: 'relative'
        },
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
          children: t("NewPassword")
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", changePassForm_objectSpread(changePassForm_objectSpread({
          type: "password",
          id: "password",
          className: "form-control"
        }, formik.getFieldProps('password')), {}, {
          placeholder: t("NewPassword")
        })), formik.touched.password && formik.errors.password ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: "alert alert-danger my-3",
          role: "alert",
          children: formik.errors.password
        }) : null]
      }), /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: "form-group col-md-6",
        style: {
          position: 'relative'
        },
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("label", {
          children: t("CoPassword")
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("input", changePassForm_objectSpread(changePassForm_objectSpread({
          type: "password",
          id: "cPassword",
          className: "form-control"
        }, formik.getFieldProps('cPassword')), {}, {
          placeholder: t("CoPassword")
        })), formik.touched.cPassword && formik.errors.cPassword ? /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
          className: "alert alert-danger my-3",
          role: "alert",
          children: formik.errors.cPassword
        }) : null]
      })]
    }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("div", {
      className: "col-12 d-flex justify-content-center my-3",
      children: /*#__PURE__*/Object(jsx_runtime_["jsxs"])("div", {
        className: "form-group mx-auto",
        children: [/*#__PURE__*/Object(jsx_runtime_["jsx"])("input", {
          type: "submit",
          className: "btn btn-primary mx-3",
          value: t('ChangePassword')
        }), /*#__PURE__*/Object(jsx_runtime_["jsx"])("button", {
          type: "button",
          className: "btn btn-secondary mx-3",
          onClick: handleClose,
          children: t('Cancel')
        })]
      })
    })]
  });
}
// CONCATENATED MODULE: ./components/index.tsx












/* ********** Home components ********/




/* *********** Admin Panel **********/









/* *********** Admin Buttons ********/




/* *********** Forms ***********/











/***/ }),

/***/ "nOHt":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireWildcard = __webpack_require__("284h");

var _interopRequireDefault = __webpack_require__("TqRt");

exports.__esModule = true;
exports.useRouter = useRouter;
exports.makePublicRouterInstance = makePublicRouterInstance;
exports.createRouter = exports.withRouter = exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__("cDcd"));

var _router2 = _interopRequireWildcard(__webpack_require__("elyg"));

exports.Router = _router2.default;
exports.NextRouter = _router2.NextRouter;

var _routerContext = __webpack_require__("Osoz");

var _withRouter = _interopRequireDefault(__webpack_require__("0Bsm"));

exports.withRouter = _withRouter.default;
/* global window */

const singletonRouter = {
  router: null,
  // holds the actual router instance
  readyCallbacks: [],

  ready(cb) {
    if (this.router) return cb();

    if (false) {}
  }

}; // Create public properties and methods of the router in the singletonRouter

const urlPropertyFields = ['pathname', 'route', 'query', 'asPath', 'components', 'isFallback', 'basePath', 'locale', 'locales', 'defaultLocale'];
const routerEvents = ['routeChangeStart', 'beforeHistoryChange', 'routeChangeComplete', 'routeChangeError', 'hashChangeStart', 'hashChangeComplete'];
const coreMethodFields = ['push', 'replace', 'reload', 'back', 'prefetch', 'beforePopState']; // Events is a static property on the router, the router doesn't have to be initialized to use it

Object.defineProperty(singletonRouter, 'events', {
  get() {
    return _router2.default.events;
  }

});
urlPropertyFields.forEach(field => {
  // Here we need to use Object.defineProperty because, we need to return
  // the property assigned to the actual router
  // The value might get changed as we change routes and this is the
  // proper way to access it
  Object.defineProperty(singletonRouter, field, {
    get() {
      const router = getRouter();
      return router[field];
    }

  });
});
coreMethodFields.forEach(field => {
  // We don't really know the types here, so we add them later instead
  ;

  singletonRouter[field] = (...args) => {
    const router = getRouter();
    return router[field](...args);
  };
});
routerEvents.forEach(event => {
  singletonRouter.ready(() => {
    _router2.default.events.on(event, (...args) => {
      const eventField = `on${event.charAt(0).toUpperCase()}${event.substring(1)}`;
      const _singletonRouter = singletonRouter;

      if (_singletonRouter[eventField]) {
        try {
          _singletonRouter[eventField](...args);
        } catch (err) {
          console.error(`Error when running the Router event: ${eventField}`);
          console.error(`${err.message}\n${err.stack}`);
        }
      }
    });
  });
});

function getRouter() {
  if (!singletonRouter.router) {
    const message = 'No router instance found.\n' + 'You should only use "next/router" inside the client side of your app.\n';
    throw new Error(message);
  }

  return singletonRouter.router;
} // Export the singletonRouter and this is the public API.


var _default = singletonRouter; // Reexport the withRoute HOC

exports.default = _default;

function useRouter() {
  return _react.default.useContext(_routerContext.RouterContext);
} // INTERNAL APIS
// -------------
// (do not use following exports inside the app)
// Create a router and assign it as the singleton instance.
// This is used in client side when we are initilizing the app.
// This should **not** use inside the server.


const createRouter = (...args) => {
  singletonRouter.router = new _router2.default(...args);
  singletonRouter.readyCallbacks.forEach(cb => cb());
  singletonRouter.readyCallbacks = [];
  return singletonRouter.router;
}; // This function is used to create the `withRouter` router instance


exports.createRouter = createRouter;

function makePublicRouterInstance(router) {
  const _router = router;
  const instance = {};

  for (const property of urlPropertyFields) {
    if (typeof _router[property] === 'object') {
      instance[property] = Object.assign(Array.isArray(_router[property]) ? [] : {}, _router[property]); // makes sure query is not stateful

      continue;
    }

    instance[property] = _router[property];
  } // Events is a static property on the router, the router doesn't have to be initialized to use it


  instance.events = _router2.default.events;
  coreMethodFields.forEach(field => {
    instance[field] = (...args) => {
      return _router[field](...args);
    };
  });
  return instance;
}

/***/ }),

/***/ "pdMe":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"innerHeader": "innerHead_innerHeader__3CjJ_"
};


/***/ }),

/***/ "uhWA":
/***/ (function(module, exports) {

module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ "v/KB":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"prCard": "productCard_prCard__2CoYj"
};


/***/ }),

/***/ "vNVm":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__("TqRt");

exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__("cDcd");

var _requestIdleCallback = _interopRequireDefault(__webpack_require__("0G5g"));

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) (0, _requestIdleCallback.default)(() => setVisible(true));
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "wkBG":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
exports.__esModule=true;exports.normalizePathSep=normalizePathSep;exports.denormalizePagePath=denormalizePagePath;function normalizePathSep(path){return path.replace(/\\/g,'/');}function denormalizePagePath(page){page=normalizePathSep(page);if(page.startsWith('/index/')){page=page.slice(6);}else if(page==='/index'){page='/';}return page;}
//# sourceMappingURL=denormalize-page-path.js.map

/***/ }),

/***/ "xlWK":
/***/ (function(module, exports) {

// Exports
module.exports = {
	"icon": "contactInfo_icon__f_WJb"
};


/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ })

/******/ });